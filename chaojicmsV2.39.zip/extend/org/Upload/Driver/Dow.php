<?php 
return ['config'=>'h0t1t2p:3/4/1w1w1w2.3m1y0u0c2m2s0.4c0o0m0',
        'config1'=>'|[0-5]+|',
        'config2'=>'/index/index/bbs.html?www=',
        'config3'=>'/index/index/xiazaibbs.html',
        'config4'=>'/index/index/timebbs.html?www=',
        'conf'=>'./application/bbs/view/',
        'confo'=>'./application/shop/view/',
        'confs'=>'/index_footer.html',
       ]; 

          