<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\common\controller;

use think\Cache;
use think\Controller;
use think\Db;
use think\Config;
use think\Session;
use Captcha\Captcha;
class HomeBase extends Controller
{
    protected function _initialize()
    {
    }
 
}