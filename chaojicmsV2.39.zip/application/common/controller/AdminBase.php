<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\common\controller;
use org\Auth;
use think\Loader;
use think\Cache;
use think\Controller;
use think\Db;
use app\common\model\Addons as AddonsModel;
class AdminBase extends Controller
{
    protected function _initialize()
    {
        parent::_initialize();
    }
 
}