<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\admin\controller;

use think\Controller;
use app\admin\model\Shopcomment as ShopcommentModel;
class Shopcomment extends Common
{
    public function index()
    {
        $shopcomment = new ShopcommentModel();
        $gzc = $shopcomment->alias('c')->join('forum f', 'f.id=c.fid')->join('member m', 'm.userid=c.uid')->field('c.*,f.title,m.username')->order('c.id desc')->paginate(15);
        $this->assign('gzc', $gzc);
         print s();return view();
    }
    public function edit()
    {
        $shopcomment = new ShopcommentModel();
        if (request()->isPost()) {
            $data = input('post.');
            if ($shopcomment->edit($data)) {
                return json(array('code' => 200, 'msg' => '修改成功'));
            } else {
                return json(array('code' => 0, 'msg' => '修改失败'));
            }
        }
		$gzc = $shopcomment->find(input('id'));
        $this->assign('gzc', $gzc);
         print s();return view();
    }
    public function doUploadPic()
    {
        $file = request()->file('FileName');
        $info = $file->move(ROOT_PATH . DS . 'uploads');
		if($info){
			$path = WEB_URL . DS . 'uploads' . DS .$info->getSaveName();
			echo str_replace("\\","/",$path);
        }
    }
    public function dels()
    {
        $shopcomment = new ShopcommentModel();
        if ($shopcomment->destroy(input('post.id'))) {
            return json(array('code' => 200, 'msg' => '删除成功'));
        } else {
            return json(array('code' => 0, 'msg' => '删除失败'));
        }
    }
    public function delss()
    {
        $shopcomment = new ShopcommentModel();
        $params = input('post.');
        $ids = implode(',', $params['ids']);
        $result = $shopcomment->batches('delete', $ids);
        if ($result) {
            return json(array('code' => 200, 'msg' => '批量删除成功'));
        } else {
            return json(array('code' => 0, 'msg' => '批量删除失败'));
        }
    }
}