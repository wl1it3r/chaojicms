<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\admin\controller;
use think\Controller;
class Point extends Common
{
    
	
	public function index()
    {
        print s();return view();
    }

	public function add()
    {
       $path = 'application/extra/point.php';
       $file = include $path;      
       $config = array(
           'JIFENNAME' => input('JIFENNAME'),
           'LOGIN_POINT' => input('LOGIN_POINT'),
		   'REG_POINT' => input('REG_POINT'),
		   'ADD_POINT' => input('ADD_POINT'),
		   'EDIT_POINT' => input('EDIT_POINT'),
		  
       );
       $res = array_merge($file, $config);
       $str = '<?php return [';
        
       foreach ($res as $key => $value){
           $str .= '\''.$key.'\''.'=>'.'\''.$value.'\''.',';
       };
       $str .= ']; ';
       if(file_put_contents($path, $str)){
           return json(array('code'=>200,'msg'=>'修改成功'));
       }else {
           return json(array('code'=>0,'msg'=>'修改失败'));
       }
    }

	
    

}
