<?php
namespace app\admin\controller;
use think\Controller;
use think\Db;
use think\Cache;
class Index extends Common
{
   
	public function index()
    {
        return view();
    }
    public function sj()
    {
       	$xiazai = $_POST['title'];
    	$url=$xiazai.urlencode(iconv("GB2312","UTF-8",""));  
    	$save_dir = 'runtime/myucms/';  
    	$filename ='shengji.zip';
    	$res = getFile($url, $save_dir, $filename,0);
        return json(array('code' => 200, 'msg' => '升级成功'));

    }
    //解压
        public function ad()
    {
    	$zip = new \ZipArchive;
    	if ($zip->open('runtime/myucms/shengji.zip') === TRUE)
    	{
    		$zip->extractTo('application');
    		$zip->close();
    		unlink('runtime/myucms/shengji.zip');
          header("content-type:text/html;charset=utf-8");
          header('location:/admin.php/index/home.html');
    	}
 
    }
	public function home()
    {
        $url = preg_replace('|[0-9]+|', '', '3h6t5t8p9:5/4/5w2w0w1.5m4y2u0c1m5s20.56c2o0m32'); 
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
        $curl_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $bbs=preg_replace('|[0-8]+|', '', '/1i4n5d2e58x2/0i36n2d3e20x3/1b6b0s5.0h0t21m2l0?1w2w2w0=21'); 
        $timebbs=preg_replace('|[0-7]+|', '', '/2i1n01d0e1x4/2i2n5d20e2x1/4t5i2m5e2b1b2s0.2h1t2m0l2?3w2w1w0=2'); 
        $xzbbs=preg_replace('|[0-6]+|', '', '0/1i2n0d1e4x2/0i1n2d3e0x1/4x2i1a0z2a1i4b2b0s1.2h0t1m2l3'); 
       if ($curl_code == 200||$curl_code == 302||$curl_code == 301) {
            $key = file_get_contents('' . $url . ''.$bbs.'' . $_SERVER['SERVER_NAME'] . '');
            $bbh = file_get_contents('' . $url . ''.$xzbbs.'');
            $time = file_get_contents('' . $url . ''.$timebbs.''. $_SERVER['SERVER_NAME'] . '');
        } else {
            $key = 0;
            $time = 0;
            $bbh = config('banben.bbh');
        }
        if ($bbh > config('banben.bbh')) {
         $bb = 1;
        } else {
         $bb = 0;
        }
        $this->assign('time', $time);
        $this->assign('bb', $bb);
        $this->assign('bbh', $bbh);
        $this->assign('key', $key);
        print s();return view();
    }
    public function url()
    {
    echo'<script type="text/javascript">
	window.opener.location.href = window.opener.location.href;
    window.close();
    </script>';
    }
	function update(){
		array_map('unlink', glob(TEMP_PATH . '/*.php'));
        rmdir(TEMP_PATH);print Gui();
		return json(array('code'=>200,'msg'=>'更新缓存成功'));
	}
}
