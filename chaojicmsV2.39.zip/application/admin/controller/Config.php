<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\admin\controller;
use think\Controller;
use think\Db;
class Config extends Common
{
    	
	public function index()
    {
        $set = Db::name('set')->order('px desc')->select();
        $this->assign('set', $set);
        print s();return view();
    }
    public function setadd()
    {
      $data = $this->request->post();
      $_data['time']=time();
      $_data['choice']=remove_xss($data['choice']);
      $_data['set']=remove_xss($data['set']);
      $_data['title']=remove_xss($data['title']);
      $_data['px']=remove_xss($data['px']);
        if (!Db::name('set')->data($_data)->insert()) {
            $this->error('添加失败');
        } else {
            $this->success('添加成功');
        } 
    }
    public function doedit()
    {
        $id = input('id');
       $data = $this->request->post();
       $data['time'] = time();
       if(Db::name('set')->where('id',$id)->data($data)->update($data)){
         $this->success('更新成功');
       } else {
           $this->error('更新失败');
        } 
    }
    public function delete()
    {
        $id = input('id');
       $data = $this->request->post();
       $data['time'] = time();
       if(Db::name('set')->where('id',$id)->data($data)->delete($data)){
         $this->success('删除成功');
        } else {
           $this->error('删除失败');
        } 
    }
  
  
	public function add()
    {
       $path = 'application/extra/web.php';
       $file = include $path;      
       $config = array(
         'WEB_RXT' => input('WEB_RXT'),
         'WEB_GL' => input('WEB_GL'),
		 'WEB_REG' => input('WEB_REG'),
		 'WEB_TAG' => input('WEB_TAG'),
		 'WEB_OPE' => input('WEB_OPE'),
         'WEB_BUG' => input('WEB_BUG'),
         'WEB_BBS' => input('WEB_BBS'),
         'WEB_SHOP' => input('WEB_SHOP'),
         'WEB_INDEX' => input('WEB_INDEX'),
         'WEB_KEJIAN' => input('WEB_KEJIAN'),
         'WEB_KEJIANS' => input('WEB_KEJIANS'),
         'Cascade' => input('Cascade'),
         //七牛
         'bucket' => input('bucket'),
         'accessKey' => input('accessKey'),
         'secrectKey' => input('secrectKey'),
         'domain' => input('domain'),
         'qiniuopen' => input('qiniuopen'),
       );
        $res = array_merge($file, $config);
        $str = '<?php return [';
        foreach ($res as $key => $value) {
            $str .= '\'' . $key . '\'' . '=>' . '\'' . $value . '\'' . ',';
        }
        $str .= ']; ';
        if (file_put_contents($path, $str)) {
            return json(array('code' => 200, 'msg' => '修改成功'));
        } else {
            return json(array('code' => 0, 'msg' => '修改失败'));
        }
    }
}