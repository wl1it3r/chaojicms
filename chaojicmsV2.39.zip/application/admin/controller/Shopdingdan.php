<?php
namespace app\admin\controller;

use think\Controller;
use app\admin\model\Shopdingdan as ShopdingdanModel;
class Shopdingdan extends Common
{
    public function index()
    {
        $shopdingdan = new ShopdingdanModel();
        
   $my = input('my');
  if ($my == '0') {
  	 $gzc = $shopdingdan->alias('c')->join('member m', 'm.userid=c.uid')->field('c.*,m.username')->where('c.open',0)->order('c.id desc')->paginate(15);

  } elseif ($my == '1') {
  	 $gzc = $shopdingdan->alias('c')->join('member m', 'm.userid=c.uid')->field('c.*,m.username')->where('c.open',1)->order('c.id desc')->paginate(15); 
  } elseif ($my == '2') {
  	 $gzc = $shopdingdan->alias('c')->join('member m', 'm.userid=c.uid')->field('c.*,m.username')->where('c.open',2)->order('c.id desc')->paginate(15);
  } elseif ($my == '3') {
  	 $gzc = $shopdingdan->alias('c')->join('member m', 'm.userid=c.uid')->field('c.*,m.username')->where('c.open',3)->order('c.id desc')->paginate(15);
  } elseif ($my == '4') {
  	 $gzc = $shopdingdan->alias('c')->join('member m', 'm.userid=c.uid')->field('c.*,m.username')->where('c.open',4)->order('c.id desc')->paginate(15);
  } elseif ($my == '9'|| $my == '') {
 $gzc = $shopdingdan->alias('c')->join('member m', 'm.userid=c.uid')->field('c.*,m.username')->order('c.id desc')->paginate(15);
  } elseif ($my == 'so') {
         $ks = input('ks');
			$gzc = $shopdingdan->alias('c')->join('member m', 'm.userid=c.uid')->field('c.*,m.username')->where('c.title|c.dingdanid|m.username','like','%'.$ks.'%','keywords','like','%'.$ks.'%')->paginate(15,false,$config = ['query'=>array('ks'=>$ks)]);
  }  
 
     $this->assign('my', $my);
 
        $this->assign('gzc', $gzc);
         print s();return view();
    }
    public function edit()
    {
        $shopdingdan = new ShopdingdanModel();
        if (request()->isPost()) {
            $data = input('post.');
            $data['timef'] = time();
            if ($shopdingdan->edit($data)) {
                return json(array('code' => 200, 'msg' => '修改成功'));
            } else {
                return json(array('code' => 0, 'msg' => '修改失败'));
            }
        }
		$gzc = $shopdingdan->find(input('id'));
        $this->assign('gzc', $gzc);
         print s();return view();
    }
    public function doUploadPic()
    {
        $file = request()->file('FileName');
        $info = $file->move(ROOT_PATH . DS . 'uploads');
		if($info){
			$path = WEB_URL . DS . 'uploads' . DS .$info->getSaveName();
			echo str_replace("\\","/",$path);
        }
    }
    public function dels()
    {
        $shopdingdan = new ShopdingdanModel();
        if ($shopdingdan->destroy(input('post.id'))) {
            return json(array('code' => 200, 'msg' => '删除成功'));
        } else {
            return json(array('code' => 0, 'msg' => '删除失败'));
        }
    }
    public function delss()
    {
        $shopdingdan = new ShopdingdanModel();
        $params = input('post.');
        $ids = implode(',', $params['ids']);
        $result = $shopdingdan->batches('delete', $ids);
        if ($result) {
            return json(array('code' => 200, 'msg' => '批量删除成功'));
        } else {
            return json(array('code' => 0, 'msg' => '批量删除失败'));
        }
    }
}