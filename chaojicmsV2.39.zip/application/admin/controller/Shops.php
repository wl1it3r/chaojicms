<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\admin\controller;

use think\Controller;
use app\admin\model\Shops as ShopsModel;
use app\admin\model\Shopcate as ShopcateModel; 
class Shops extends Common
{
    public function index()
    {
        $shops = new ShopsModel();
		$ks=input('ks');
        $gzc = $shops->alias('f')->join('shopcate c', 'c.id=f.tid')->field('f.*,c.id as cid,c.name')->order('f.id desc')->where('title','like','%'.$ks.'%')->paginate(15,false,$config = ['query'=>array('ks'=>$ks)]);
        $this->assign('gzc', $gzc);
        return view();
    }
    public function edit()
    {
        $shops = new ShopsModel();
        if (request()->isPost()) {
            $data = input('post.');
            $data['time'] = time();
            if ($shops->edit($data)) {
                return json(array('code' => 200, 'msg' => '修改成功'));
            } else {
                return json(array('code' => 0, 'msg' => '修改失败'));
            }
        }
      
       $shopcate = new ShopcateModel();       
        $gzc = $shops->find(input('id'));
        $this->assign(array('gzc' => $gzc));
      $gzcs = $shopcate->where("tid = 0")->order('sort desc')->select();           
      $gjms = $shopcate->where("tid != 0")->order('sort desc')->select();         
      $this->assign('gzcs', $gzcs);    
      $this->assign('gjms', $gjms);
        return view();
    }
    public function add()
    {

      $shopcate = new ShopcateModel();
            $shops = new ShopsModel();
            if (request()->isPost()) {
                $data = input('post.');
                $data['time'] = time();
                $data['view'] = 1;
                $data['uid'] = 1;
                if ($shops->add($data)) {
                    return json(array('code' => 200, 'msg' => '添加成功'));
                } else {
                    return json(array('code' => 0, 'msg' => '添加失败'));
                }
            }
            $gzc = $shopcate->where("tid = 0")->order('sort desc')->select();
            $gjm = $shopcate->where("tid != 0")->order('sort desc')->select();
            $this->assign('gzc', $gzc);
            $this->assign('gjm', $gjm);
        return view();
    }
  
    public function doUploadPic()
    {
        $file = request()->file('FileName');
        $info = $file->move(ROOT_PATH . DS . 'uploads');
		if($info){
			$path = WEB_URL . DS . 'uploads' . DS .$info->getSaveName();
			echo str_replace("\\","/",$path);
        }
    }
    public function dels()
    {
        $shops = new ShopsModel();
        if ($shops->destroy(input('post.id'))) {
            return json(array('code' => 200, 'msg' => '删除成功'));
        } else {
            return json(array('code' => 0, 'msg' => '删除失败'));
        }
    }
    public function delss()
    {
        $shops = new ShopsModel();
        $params = input('post.');
        $ids = implode(',', $params['ids']);
        $result = $shops->batches('delete', $ids);
        if ($result) {
            return json(array('code' => 200, 'msg' => '批量删除成功'));
        } else {
            return json(array('code' => 0, 'msg' => '批量删除失败'));
        }
    }
    public function changechoice()
    {
        if (request()->isAjax()) {
            $change = input('change');
            $choice = db('shops')->field('choice')->where('id', $change)->find();
            $choice = $choice['choice'];
            if ($choice == 1) {
                db('shops')->where('id', $change)->update(['choice' => 0]);
                echo 1;
            } else {
                db('shops')->where('id', $change)->update(['choice' => 1]);
                echo 2;
            }
        } else {
            $this->error('非法操作');
        }
    }
    public function changesettop()
    {
        if (request()->isAjax()) {
            $change = input('change');
            $settop = db('shops')->field('settop')->where('id', $change)->find();
            $settop = $settop['settop'];
            if ($settop == 1) {
                db('shops')->where('id', $change)->update(['settop' => 0]);
                echo 1;
            } else {
                db('shops')->where('id', $change)->update(['settop' => 1]);
                echo 2;
            }
        } else {
            $this->error('非法操作');
        }
    }
    public function changeopen()
    {
        if (request()->isAjax()) {
            $change = input('change');
            $open = db('shops')->field('open')->where('id', $change)->find();
            $open = $open['open'];
            if ($open == 1) {
                db('shops')->where('id', $change)->update(['open' => 0]);
                echo 1;
            } else {
                db('shops')->where('id', $change)->update(['open' => 1]);
                echo 2;
            }
        } else {
            $this->error('非法操作');
        }
    }
}