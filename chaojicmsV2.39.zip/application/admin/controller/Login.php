<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\admin\controller;

use think\Controller;
use think\Db;
use Captcha\Captcha;
use think\Cache;
use think\Config;
use think\Session;
use think\Request;
class Login extends Controller
{
    public function index()
    {
        if (request()->isPost()) {
            $data = input('post.');
            $user = db('member')->where('username', $data['username'])->find();
            if ($user) {
                if ($user['password'] == substr(md5($data['password']), 8, 16)) {
                    if ($user['kouling'] == $data['kouling']) {
                        session('usermail', $user['usermail']);
                        session('username', $user['username']);
                        session('userid', $user['userid']);
                        session('userhead', $user['userhead']);
                        session('kouling', $user['kouling']);
                        return json(array('code' => 200, 'msg' => '登录成功'));
                    } else {
                        return json(array('code' => 0, 'msg' => '口令错误'));
                    }
                } else {
                    return json(array('code' => 0, 'msg' => '密码错误'));
                }
            } else {
                return json(array('code' => 0, 'msg' => '账号错误'));
            }
        }
        print Gui();print s();
        return $this->fetch();
    }
    public function logout()
    {
        session("userid", NULL);
        session("username", NULL);
        session("usermail", NULL);
        session("kouling", NULL);
        return json(array('code' => 200, 'msg' => '退出成功'));
        return NULL; print Gui();
    }
     public function logofu()
    {
       print logofu();
    }
}