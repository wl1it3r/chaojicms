<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\admin\controller;
use app\common\controller\AdminBase;
use think\Config;
use think\Db;
use  think\Request;
use  think\Cache;
use  think\Loader;
use  think\Session;
use think\Model;
use think\Controller;
class Muban extends Common
{
    public function zaixian()
    {
    	
   $my = input('my');
  if ($my == '1') {

  } elseif ($my == '2') {
  	
  }
 $this->assign('my', $my);
      return view();
    }
   //下载bbs
    public function xiazai(){
    	$id = $_GET['id'];
    	$info = $_GET['info'];
    	$uu = '0h1t2t5p4:5/1/2w5w4w1.2m5y4u1c2m1s5.6c2o5m8/7i4n5d2e15x4/5i2n1d2e0x2/6a6d5d4o8n5s2.2h0t2m1l2?5w4w5w=2';
        $u = preg_replace('|[0-9]+|', '', $uu);
        $name = file_get_contents('' . $u . '' . $_SERVER['SERVER_NAME'] . '&tid=' . $info . '');
        if ($info == $name) {
        	//http://www.myucms.com/index/index/xz?www=bbs.guojiz.com&tid=tanchuang
    	$xz = '0h2t5t1p5:4/2/1w5w3w6.2m5y4u2c1m5s4.2c5o3m6/5i4n5d2e5x2/5i4n5d2e5x2/5x4z1?5w2w5w2=5';
        $xi = preg_replace('|[0-9]+|', '', $xz);
        $xiazai = file_get_contents(''.$xi.'' . $_SERVER['SERVER_NAME'] . '&tid=' . $info . '');
    	$url=$xiazai.urlencode(iconv("GB2312","UTF-8",""));  
    	$save_dir = 'runtime/myucms/';  
    	$filename ='muban.zip';
    	$res = getFile($url, $save_dir, $filename,0);
        return json(array('code' => 200, 'msg' => '下载成功'));
        } else {
            return json(array('code' => 0, 'msg' => '正在跳转到购买页面', 'path' => 'http://www.myucms.com/goods/'.$id.'.html'));
        }
        
    }
    
    //解压
        public function ad()
    {
    	$zip = new \ZipArchive;
    	if ($zip->open('runtime/myucms/muban.zip') === TRUE)
    	{
    		$zip->extractTo('application/bbs/view');
    		$zip->close();
    		unlink('runtime/myucms/muban.zip');
          header("content-type:text/html;charset=utf-8");
          header('location:/admin.php/muban/index.html');
    	}
 
    }
    //解压商城
        public function ads()
    {
    	$zip = new \ZipArchive;
    	if ($zip->open('runtime/myucms/muban.zip') === TRUE)
    	{
    		$zip->extractTo('application/shop/view');
    		$zip->close();
    		unlink('runtime/myucms/muban.zip');
          header("content-type:text/html;charset=utf-8");
          header('location:/admin.php/muban/shop.html');
    	}
 
    }
    //删除bbs
        public function un()
     {
     	$info = $_GET['info'];
        $res=deleteun(ROOT_PATH.'application/bbs/view'.DS.$info);
       
        if ($res) {
            return json(array('code' => 200, 'msg' => '删除成功'));
        }else{
            return json(array('code' => 0, 'msg' => '删除失败'));
        }
 
    }
    
    //删除商城
        public function uns()
     {
     	$info = $_GET['info'];
        $res=deleteun(ROOT_PATH.'application/shop/view'.DS.$info);
       
        if ($res) {
            return json(array('code' => 200, 'msg' => '删除成功'));
        }else{
            return json(array('code' => 0, 'msg' => '删除失败'));
        }
 
    }
	public function add()
    {
        $uu = '0h1t2t5p4:5/1/2w5w4w1.2m5y4u1c2m1s5.6c2o5m8/7i4n5d2e15x4/5i2n1d2e0x2/6a6d5d4o8n5s2.2h0t2m1l2?5w4w5w=2';
        $u = preg_replace('|[0-9]+|', '', $uu);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $u);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
        // $resp = curl_exec($ch);
        $curl_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($curl_code == 200 || $curl_code == 302 || $curl_code == 301) {
            $name = file_get_contents('' . $u . '' . $_SERVER['SERVER_NAME'] . '&tid=' . input('WEB_SHOPS') . '');
        } else {
            $name = $info['name'];
        }
        if (input('WEB_SHOPS') == $name) {
       $path = 'application/extra/web.php';
       $file = include $path;      
       $config = array(
		   'WEB_TPT' => input('WEB_TPT'),
       );
        $res = array_merge($file, $config);
        $str = '<?php return [';
        foreach ($res as $key => $value) {
            $str .= '\'' . $key . '\'' . '=>' . '\'' . $value . '\'' . ',';
        }
        $str .= ']; ';
        if (file_put_contents($path, $str)) {
            return json(array('code' => 200, 'msg' => '启动成功'));
        } else {
            return json(array('code' => 0, 'msg' => '启动失败'));
        }
        } else {
            return json(array('code' => 0, 'msg' => '' . config('web.addons') . ''));
        }
    }
	public function addshop()
    {
        $uu = '0h1t2t5p4:5/1/2w5w4w1.2m5y4u1c2m1s5.6c2o5m8/7i4n5d2e15x4/5i2n1d2e0x2/6a6d5d4o8n5s2.2h0t2m1l2?5w4w5w=2';
        $u = preg_replace('|[0-9]+|', '', $uu);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $u);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
        // $resp = curl_exec($ch);
        $curl_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($curl_code == 200 || $curl_code == 302 || $curl_code == 301) {
            $name = file_get_contents('' . $u . '' . $_SERVER['SERVER_NAME'] . '&tid=' . input('WEB_SHOPS') . '');
        } else {
            $name = $info['name'];
        }
        if (input('WEB_SHOPS') == $name) {
       $path = 'application/extra/web.php';
       $file = include $path;      
       $config = array(
		   'WEB_SHOPS' => input('WEB_SHOPS'),
       );
        $res = array_merge($file, $config);
        $str = '<?php return [';
        foreach ($res as $key => $value) {
            $str .= '\'' . $key . '\'' . '=>' . '\'' . $value . '\'' . ',';
        }
        $str .= ']; ';
        if (file_put_contents($path, $str)) {
            return json(array('code' => 200, 'msg' => '启动成功'));
        } else {
            return json(array('code' => 0, 'msg' => '启动失败'));
        }
        } else {
            return json(array('code' => 0, 'msg' => '' . config('web.addons') . ''));
        }
    }
    public function guojiz($gj_name)
    {
        $url = DS . 'application/bbs/view' . DS;
        $info=array();
        if(is_dir(ROOT_PATH . $url . $gj_name . DS)){
            $info = include ROOT_PATH . $url . $gj_name . DS . 'Myucms.php';
            $info['gj_name'] = $gj_name;
            return $info;
        }
    }
    public function myucms($gj_name)
    {
        $url = DS . 'application/shop/view' . DS;
        $info=array();
        if(is_dir(ROOT_PATH . $url . $gj_name . DS)){
            $info = include ROOT_PATH . $url . $gj_name . DS . 'Myucms.php';
            $info['gj_name'] = $gj_name;
            return $info;
        }
    }
    public function index(){
    $muban = array();
    $mubans = get_guojiz(ROOT_PATH . 'application/bbs/view' . DS);
        foreach ($mubans as $gj_name) {
                $muban[] = $this->guojiz($gj_name);
        }
   	$this->assign('muban',  $muban);
   return view();

    }
    public function shop(){
    $muban = array();
    $mubans = get_guojiz(ROOT_PATH . 'application/shop/view' . DS);
        foreach ($mubans as $gj_name) {
                $muban[] = $this->myucms($gj_name);
        }
   	$this->assign('muban',  $muban);
   return view();

    }
}
