<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\admin\controller;
use think\Controller;
use org\Auth;
use think\Loader;
use think\Cache;
use think\Db;
use think\Session;
use app\common\model\Addons as AddonsModel;


class Common extends Controller
{
    public function _initialize(){
        if(!session('usermail') || !session('kouling')){
           $this->error('请登录',url('login/index')); 
           print s();
        }
	
    }

}
