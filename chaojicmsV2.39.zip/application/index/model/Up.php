<?php
namespace app\index\model;
use Think\Loader;
use think\Model;
use think\Db;
use think\File;
use think\Request;
use org\Http;
use org\Upload;
use think\Cache;
class Up extends Model
{
	
	function initialize()
	{
		parent::initialize();
	}

	public function upfile($type,$filename = 'file',$is_water = false){
      
      if (config('web.qiniuopen') == 1) {
            $driverConfig = array('secrectKey' => config('web.secrectKey'), 'accessKey' => config('web.accessKey'), 'domain' => config('web.domain'), 'bucket' => config('web.bucket'));
            $setting = array('rootPath' => './', 'saveName' => array('uniqid', ''), 'hash' => true);
            $setting['exts'] = explode(',', config('web.WEB_RXT'));
            $setting['maxSize'] = 50 * 1024 * 1024;
            $File = $_FILES['file'];
            $Upload = new Upload($setting, 'Qiniu', $driverConfig);
            $info = $Upload->uploadOne($File);
            if ($info) {
                $data['sha1'] = $info['sha1'];
                $data['md5'] = $info['md5'];
                $data['create_time'] = time();
                $data['uid'] = session('userid');
                $data['download'] = 0;
                $data['size'] = $info['size'];
                $data['name'] = $info['name'];
                $data['ext'] = $info['ext'];
                $data['savepath'] = $info['url'];
                $data['savename'] = $info['savename'];
                $data['mime'] = $info['type'];
                $map['md5'] = $info['md5'];
                $mmn = Db::name('file')->where($map)->find();
                if (empty($mmn)) {
                    Db::name('file')->insert($data);
                    $res = Db::name('file')->getLastInsID();
                    if ($res > 0) {
                        return array('code' => 200, 'msg' => '上传成功', 'hasscore' => 0, 'ext' => $data['ext'], 'id' => $res, 'headpath' => $data['savepath'],'path' => $data['savepath'], 'md5' => $data['md5'], 'savename' => $data['savename'], 'filename' => $data['name'], 'info' => $info);
                    } else {
                        return array('code' => 0, 'msg' => '上传失败');
                    }
                } else {
                    return array('code' => 200, 'msg' => '上传成功', 'hasscore' => 1, 'ext' => $mmn['ext'], 'id' => $mmn['id'], 'headpath' => $data['savepath'],'path' => $mmn['savepath'], 'md5' => $mmn['md5'], 'savename' => $mmn['savename'], 'filename' => $mmn['name'], 'info' => $mmn);
                }
            } else {
                return array('code' => 0, 'msg' => $Upload->getError());
            }
     } else {
		$file = request()->file($filename);
        $md5 = $file->hash('md5');
            $n = Db::name('file')->where('md5', $md5)->find();
            if (empty($n)) {
                $info = $file->validate(['size' => 50 * 1024 * 1024, 'ext' => config('web.WEB_RXT')])->move(ROOT_PATH . DS . 'uploads');
                if ($info) {
                    $path = DS . 'uploads' . DS . $info->getSaveName();
                    $path = str_replace("\\", "/", $path);
                    $realpath = WEB_URL . $path;
                    $data['sha1'] = $info->sha1();
                    $data['md5'] = $info->md5();
                    $data['create_time'] = time();
                    $data['uid'] = session('userid');
                    $data['download'] = 0;
                    $data['size'] = $info->getSize();
                    $fileinfo = $info->getInfo();
                    $data['name'] = $fileinfo['name'];
                    $data['ext'] = $info->getExtension();
                    $data['savepath'] = $path;
                    $data['savename'] = $info->getFilename();
                    $data['mime'] = $fileinfo['type'];
                    Db::name('file')->insert($data);
                    $res = Db::name('file')->getLastInsID();
                  
                    if ($res > 0) {
                        return array('code' => 200, 'msg' => '上传成功', 'hasscore' => 0, 'ext' => $data['ext'], 'id' => $res, 'path' => $path, 'headpath' => $realpath, 'md5' => $data['md5'], 'savename' => $data['savename'], 'filename' => $data['name'], 'info' => $info->getInfo());
                    } else {
                        return array('code' => 0, 'msg' => '上传失败');
                    }
                } else {
                    return array('code' => 0, 'msg' => $file->getError());
                }
            } else {
                $path = $n['savepath'];
                $realpath = WEB_URL . $path;
                return array('code' => 200, 'msg' => '上传成功', 'hasscore' => 1, 'ext' => $n['ext'], 'id' => $n['id'], 'path' => $path, 'headpath' => $realpath, 'md5' => $n['md5'], 'savename' => $n['savename'], 'filename' => $n['name'], 'info' => $n);
              
            }
        }
   }               
 
}