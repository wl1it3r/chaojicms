<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\index\controller;
use app\common\controller\HomeBase;
use think\Controller;
use think\Session;
use think\Db;
/**
 * 扩展控制器
 * 用于调度各个扩展的URL访问需求
 */
class Addons extends HomeBase{
	protected $addons = null;
	public function myu($c = null, $m = null, $s = null,$json=false){
		$class_path = "\\".ADDON_DIR_NAME."\\".$c."\controller\\".$m;
    	$controller = new $class_path();
	if($json){
    		return json($controller->$s());
    	}else{
    		$controller->$s();
    	}
	}
	/**
	 * 获取插件的配置数组
	 */
	public function getConfig($name=''){
		$config =   array();
		$map['name']    =   $name;
		$map['status']  =   1;
		$config  =   Db::name('addons')->where($map)->value('config');
		$config   =   json_decode($config, true);
        print s();
		return $config;
	}
	
	

}
