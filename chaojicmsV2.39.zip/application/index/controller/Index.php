<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\index\controller;
use think\Controller;
use think\Db;
class Index extends Controller
{
    function _initialize()
    {
        parent::_initialize();
    }
  
   public function index(){
          $this->redirect(url(config('web.WEB_INDEX')));
   }
}