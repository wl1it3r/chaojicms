<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\index\controller;

use think\Controller;
class Upload extends Controller
{
    function _initialize()
    {
        parent::_initialize();
        $this->model = model('index/up');
        
    }
    public function upimage()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('bbs/login/index'));
        } else {
        return json($this->model->upfile('images'));
        }
    }
    public function upfile()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('bbs/login/index'));
        } else {
        return json($this->model->upfile('files'));
        }
    }
 
 
 
    public function Pic()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('bbs/login/index'));
        } else {
			$file = request()->file('FileName');
			$info = $file->validate(['size'=>50000,'ext'=>'jpg,png,gif'])->move(ROOT_PATH . DS . 'uploads');
			if ($info) {
				$path = WEB_URL . DS . 'uploads' . DS . $info->getSaveName();
				echo str_replace("\\", "/", $path);
              }
		}
    }
 
}