<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\shop\controller;
use org\Http;
use think\Controller;
use think\Db;
class Index extends Controller
{
    public function _initialize()
    {
        parent::_initialize();
        if (config('web.WEB_SHOP') == 0) {
           $this->redirect(url('index/index/index'));
        }
    }
  
    //首页
    public function index()
    {
        //分类展示
        $show['show'] = 1;
        $shopcate = Db::name('shopcate');
        $gjfl = $shopcate->where("tid = 0")->where($show)->order('sort desc')->select();
        foreach ($gjfl as $ks => $vc) {
            $gjfl[$ks]['count'] = Db::name('shops')->where('tid', $vc['id'])->count();
        }
        $this->assign('gjfl', $gjfl);
        $gjz = $shopcate->where("tid != 0")->where($show)->order('sort desc')->select();
        foreach ($gjz as $ks => $vc) {
            $gjz[$ks]['count'] = Db::name('shops')->where('tid', $vc['id'])->count();
        }
        $this->assign("gjz", $gjz);
        print s();
        return view();
    }
//搜索
	public function search()
    {
         $ks = input('ks');
        if (empty($ks)) {
            return $this->error('亲！你迷路了');
        } else {
			$open['open'] = 1;
			$gzc = Db::name('shops')->alias('f')->join('category c', 'c.id=f.tid')->join('member m', 'm.userid=f.uid')->field('f.*,c.id as cid,m.userid,m.userhead,m.username,c.name')->order('f.id desc')->where($open)->where('f.title|f.keywords','like','%'.$ks.'%')->paginate(16,false,$config = ['query'=>array('ks'=>$ks)]);
			$this->assign('gzc', $gzc);
			return view();
		}
    }
//列表
    public function grid($or)
    {
        $or = input('or');
        $this->assign('or', $or);
        $id = input('id');
        $this->assign('id', $id);
        if (empty($id)) {
          $open['open'] = 1;
          $gzc = Db::name('shops')->alias('f')->join('shopcate c', 'c.id=f.tid')->join('member m', 'm.userid=f.uid')->field('f.*,c.id as cid,m.userid,m.userhead,m.username,c.name,c.description')->where($open)->order('f.settop desc , f.'.$or.' desc') -> paginate(16,false,['query' => request()->param()]);
          $this->assign('gzc', $gzc);
          $shopcate = Db::name('shopcate');
          $gzcz = $shopcate->where("tid = 0")->order('sort desc')->select();
          $gjmz = $shopcate->where("tid != 0")->order('sort desc')->select();
          $this->assign('gzcz', $gzcz);
          $this->assign('gjmz', $gjmz);
          $ids = -1;
          $this->assign('ids', $ids);
        } else {
            $shopcate = Db::name('shopcate');
            $c = $shopcate->where("id = {$id}")->find();
            if ($c) {
              $shopcate = Db::name('shopcate');
              $gzcz = $shopcate->where("tid = 0")->order('sort desc')->select();
              $gjmzt = $shopcate->where("id = {$id}")->value('tid');
              if ($gjmzt==0) {
               $gjmz = $shopcate->where("tid = {$id}")->order('sort desc')->select();
               } else {
                 $gjmz = $shopcate->where("{$c['tid']}=tid")->order('sort desc')->select();
              }
              foreach ($gjmz as $ks =>$vc){
                $gjmz[$ks]['count']	= Db::name('shops')->where('tid',$vc['id'])->count();	
              }
              $this->assign('gzcz', $gzcz);
              $this->assign('gjmz', $gjmz);
                $forum = Db::name('shops');
                $open['open'] = 1;
                $shopcate = Db::name('shopcate');
                $c = $shopcate->where('id', $id)->find();
                $cs = $shopcate->where('id', $c['tid'])->find();
                $open['open'] = 1;
                $id = $c['id'];
                $description = $c['description'];
                $keywords = $c['keywords'];
                $name = $c['name'];
                $names = $cs['name'];
                $ids = $cs['id'];
                $pic = $c['pic'];
                $gzc = $forum->alias('f')->join('shopcate c', 'c.id=f.tid')->join('member m', 'm.userid=f.uid')->field('f.*,c.id as cid,m.userid,m.userhead,m.username,c.name,c.description')->where("f.tid={$id} or c.tid={$id}")->where($open)->order('f.settop desc , f.'.$or.' desc')-> paginate(16,false,['query' => request()->param()]);
                $countv	= Db::name('shops')->where('tid',$c['id'])->count();
                $this->assign('gzc', $gzc);
                $this->assign('countv', $countv);
                $this->assign('name', $name);
                $this->assign('ids', $ids);
                $this->assign('names', $names);
                $this->assign('pic', $pic);
                $this->assign('keywords', $keywords);
                $this->assign('description', $description);
            } else {
                $this->error("亲！你迷路了！");
            }
          } 
      return view();
    }
//详情页面
	public function goods()
    {
        $id = input('id');
        if (empty($id)) {
            return $this->error('亲！你迷路了');
        } else {

            $forum = Db::name('shops');
            $a = $forum->where("id = {$id}")->find();
            if ($a) {
                $forum->where("id = {$id}")->setInc('view', 1);
                $t = $forum->alias('f')->join('shopcate c', 'c.id=f.tid')->join('member m', 'm.userid=f.uid')->field('f.*,c.id as cid,c.name,m.userid,m.grades,m.point,m.userhead,m.username')->find($id);
                $this->assign('t', $t);
                $content = $t['content'];
                $content = htmlspecialchars_decode($content);
                $this->assign('content', $content);
                $gzc = Db::name('shopcomment')->alias('c')->join('member m', 'm.userid=c.uid')->where("fid = {$id}")->order('c.id desc')->paginate(15);
                $this->assign('gzc', $gzc);
                print s();return view();
            } else {
                return $this->error('亲！你迷路了');
            }
          return view();
          }
		 
    }
//加入购物车
    public function tijiao()
    {
      if (!session('userid') || !session('username')) {
        $this->error('请登录');
      } else {
      $data = $this->request->post();
      $id = input('id');
      $t = Db::name('shops')->find($id);
      $_data['time']=time();
      $_data['tid']=input('id');
      $_data['title']=$t['title'];
      $_data['xn']=$t['xn'];
      $_data['lianjie']=$t['lianjie'];
      $_data['uid'] = session('userid');
      $_data['dingdanid']=generate_password(18);
       if ($t['xn']==0) {
      $_data['jifen']=$t['jifen']*remove_xss($data['shuliang']);
      $_data['shuliang']=remove_xss($data['shuliang']);
      $_data['guige']=remove_xss($data['guige']);
      $_data['open']=0;
       } else {
      $_data['jifen']=$t['jifen'];
      $_data['open']=4;
       } 
     Db::name('shops')->where("id = {$id}")->setInc('sc', 1);
        if (!Db::name('shopdingdan')->data($_data)->insert()) {
            $this->error('加入失败');
        } else {
            return json(array('code'=>200,'msg'=>'添加成功'));
        } 
    }
    }
//添加地址
    public function dizhi()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('login/index'));
        } else {
      $data = $this->request->post();
      $_data['uid'] = session('userid');
      $_data['time']=time();
      $_data['name']=remove_xss($data['name']);
      $_data['title']=remove_xss($data['title']);
      $_data['dizhi']=remove_xss($data['dizhi']);
      $_data['lianxi']=remove_xss($data['lianxi']);
        if (!Db::name('shopdizhi')->data($_data)->insert()) {
            $this->error('添加失败');
        } else {
            $this->success('添加成功');
        } 
        }
    }
//用户评分并且确定收货
    public function pingfen()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('login/index'));
        } else {
      $data = $this->request->post();
       $id = input('id');
       $datas['timess'] = time();
       $datas['open']=3;
      $_data['uid'] = session('userid');
      $_data['time']=time();
      $_data['fid']=remove_xss($data['fid']);
       $_data['pingfen']=remove_xss($data['pingfen']);
      $_data['content']=remove_xss($data['content']);
      Db::name('shops')->where('id',remove_xss($data['fid']))->setInc('reply', 1);
        if (!Db::name('shopcomment')->data($_data)->insert()) {
            return array('code' => 200, 'msg' =>  '评论失败');
        } else {
        	Db::name('shopdingdan')->where('id',$id)->where('uid',session('userid'))->update($datas);
           return array('code' => 200, 'msg' =>  '评论成功');
           
        } 
        }
    }
  
//订单支付
    public function shopsetS()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('login/index'));
        } else {
       $data=$this->request->post();
       $id = input('id');
       $ts = Db::name('shopdingdan')->find($id);
       $data['times'] = time();
       if ($ts['xn']==0) {
       $data['open']=1;
       } else {
       $data['open']=5;
       $data['timess'] = time();
       $data['timef'] = time();
       } 
       $t = Db::name('shopdizhi')->find(remove_xss($data['name']));
       $data['name']=$t['name'];
       $data['dizhi']=$t['dizhi'];
       $data['lianxi']=$t['lianxi'];
       //查询有没有积分
       $point = Db::name('member')->where('userid', session('userid'))->value('point');
       if ($point < $ts['jifen'] && $ts['jifen'] > 0) {
           return array('code' => 0, 'msg' =>  '余额不足，请充值后支付.');
       }
                    
       if(Db::name('shopdingdan')->where('id',$id)->where('uid',session('userid'))->update($data)){
       	//添加评价累计
       	Db::name('shops')->where('id',$ts['tid'])->setInc('xiaoliang', 1);
       	//添加支付记录
       	$point_note = array('controller'=>$ts['title'], 'uid'=>session('userid'),'pointid'=>$ts['tid'],'score'=>$ts['jifen'],'add_time'=>time());
        $tsc = Db::name('shops')->find($ts['tid']);
        //添加积分记录
        point($ts['jifen'], session('userid'), '商城：' . $tsc['title']  ,$tsc['id']);
        //扣掉积分记录
        points($ts['jifen'], $tsc['uid'], '商城：' . $tsc['title']  ,$tsc['id']);
       if ($ts['xn']==0) {
         return array('code' => 200, 'msg' =>  '支付成功');
       } else { 
       	return array('code' => 200, 'msg' => '支付成功...', 'path' => $ts['lianjie']);
       }
       }else{
         $this->error('支付失败');
       }
    }
    }

//删除订单
    public function shopset()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('login/index'));
        } else {
       $data = $this->request->post();
       $id = input('id');
       if(Db::name('shopdingdan')->where('id',$id)->where('uid',session('userid'))->data($data)->delete($data)){
         $this->success('删除成功');
        } else {
           $this->error('删除失败');
        } 
        } 
    }
//删除地址
    public function shopsetc()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('login/index'));
        } else {
       $data = $this->request->post();
       $id = input('id');
       if(Db::name('shopdizhi')->where('id',$id)->where('uid',session('userid'))->data($data)->delete($data)){
         $this->success('删除成功');
        } else {
           $this->error('删除失败');
        } 
    }
    }
 
    public function dingdan()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('login/index'));
        } else {
   $my = input('my');
  if ($my == '0' || $my == '') {
  	//购物车
     $dingdan = Db::name('shopdingdan')->where('open',0)->where('uid',session('userid'))->order('time desc')->paginate(15);
  } elseif ($my == '1') {
  	//等待发货
  	$dingdan = Db::name('shopdingdan')->where('open',1)->where('uid',session('userid'))->order('time desc')->paginate(15);  
  } elseif ($my == '2') {
  	//已发货
  	$dingdan = Db::name('shopdingdan')->where('open',2)->where('uid',session('userid'))->order('timef desc')->paginate(15);  
  } elseif ($my == '3') {
  	//已收货
  	$dingdan = Db::name('shopdingdan')->where('open',3)->where('uid',session('userid'))->order('timess desc')->paginate(15);  
  } elseif ($my == '4') {
  	//虚拟订单
  	$dingdan = Db::name('shopdingdan')->where('open',4)->where('uid',session('userid'))->order('time desc')->paginate(15);  
  } elseif ($my == '5') {
  	//虚拟订单评论
  	$dingdan = Db::name('shopdingdan')->where('open',5)->where('uid',session('userid'))->order('time desc')->paginate(15);  
  } elseif ($my == '9') {
  	$dingdan = Db::name('shopdingdan')->where('uid',session('userid'))->order('time desc')->paginate(15);  
  }  
  $this->assign('dingdan', $dingdan);
  $this->assign('my', $my);
    return view();
    }
}

}