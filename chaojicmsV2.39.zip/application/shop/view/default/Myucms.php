<?php
return array(
'title'=>'商城默认模板',
'zuozhe'=>'梦雨',
'name'=>'default',
'pic'=>'/application/shop/view/default/public/img/pic.jpg',	
'bb'=>'1.0',
'lianjie'=>'www.myucms.com',
);