<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
 $ids = (include 'application/extra/web.php');
 $y = $ids['WEB_TPT'];
 $s = $ids['WEB_SHOPS'];
 $bug = $ids['WEB_BUG'];
return [
    'app_debug'              =>  $bug,
   'session'                => [
        'id'             => '',
        // SESSION_ID的提交变量,解决flash上传跨域
        'var_session_id' => '',
        // SESSION 前缀
        'prefix'         => 'index',
        // 驱动方式 支持redis memcache memcached
        'type'           => '',
        // 是否自动开启 SESSION
        'auto_start'     => true,
        //过期时间 单位秒
      //  'path'=>TEMP_PATH,//表示session保存在自己网站根目录中的runtime目录中
         'expire'=>3600*24*30,//过期时间
    ],

    'view_replace_str'  =>  [
	'__ROOT__' => WEB_URL,
	'__INDEX__' => WEB_URL . '/index.php',
	'__ADMIN__' => WEB_URL . '/public',
	'__HOME__' => WEB_URL . '/application/bbs/view/'.$y.'/public',
	'__SHOP__' => WEB_URL . '/application/shop/view/'.$s.'/public',
     '__ FILE__' => WEB_URL . '/update',
    ],
];
