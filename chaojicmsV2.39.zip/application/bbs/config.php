<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
if(isMobile()==true){
$open='view';
}else{ 
$open='view';
}
return [
	'template'=> [
    'view_path'    => './application/bbs/'.$open.'/'.config('web.WEB_TPT').'/',
    'view_suffix' => 'html',
	'view_depr'    => '_',
    ],

	'url_html_suffix' => 'html',
	'url_route_on'  =>  true,

];
