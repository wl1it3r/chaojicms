<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\bbs\controller;
use think\Controller;
use think\Db;
use app\bbs\model\Member as MemberModel;
class User extends Controller
{
    public function index()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('login/index'));
        } else {
            $forum = Db::name('forum');
            $uid = session('userid');
            $gzc = $forum->where("uid = {$uid}")->order('id desc')->paginate(10);
            $this->assign('gzc', $gzc);
            return view();
        }
    }
	public function comment()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('login/index'));
        } else {
            $comment = Db::name('comment');
            $uid = session('userid');
            $gzc = $comment->alias('c')->join('forum f', 'f.id=c.fid')->field('c.*,f.title')->where("c.uid = {$uid}")->order('c.id desc')->paginate(5);
            $this->assign('gzc', $gzc);
            return view();
        }
    }
    public function home()
    {
        $id = input('id');
        if (empty($id)) {
            return $this->error('亲！你迷路了');
        } else {
            $member = new MemberModel();
            $m = $member->where("userid = {$id}")->find($id);
            if ($m) {
                $this->assign('m', $m);
				$forum = Db::name('forum');
                $gzc = $forum->where("uid = {$id}")->order('id desc')->limit(10)->select();
                $this->assign('gzc', $gzc);
				$comment = Db::name('comment');
                $gze = $comment->alias('c')->join('forum f', 'f.id=c.fid')->field('c.*,f.title')->where("c.uid = {$id}")->order('c.id desc')->limit(5)->select();
                $this->assign('gze', $gze);
                print s();return view();
            } else {
                return $this->error('亲！你迷路了');
            }
        }
    }
    public function set()
    {
        if (!session('userid') || !session('username')) {
              $this->error('亲！请登录', url('login/index'));
        } else {
            $member = new MemberModel();
            $uid = session('userid');
            $gzc = $member->where(array('userid' => $uid))->find();
            if (request()->isPost()) {
                $data = $this->request->post();
                $data['userid'] = $uid;

                    $_data['username'] = remove_xss($data['username']);
                    if (is_numeric($_data['username']) || is_numeric(substr($_data['username'], 0, 1)) || mb_strwidth($_data['username']) < 4) {
                        return json(array('code' => 0, 'msg' => '不能是纯数字或数字开头，一个汉字算2个字符'));
                    }
                    $_data['userhome'] = remove_xss($data['userhome']);
                    $_data['description'] = remove_xss($data['description']);
                    $_data['sex'] = $data['sex'];
                    $_data['usermail'] = $data['usermail'];
                    if ($member->save($_data, ['userid' => $uid])) {
                        return json(array('code' => 200, 'msg' => '修改成功'));
                    } else {
                        return json(array('code' => 0, 'msg' => '修改失败'));
                    }
            }
            $uid = session('userid');
            $this->assign('gzc', $gzc);
            $this->assign('uid', $uid);
            return view();
        }
    }
    public function setedit()
    {
        if (!session('userid') || !session('username')) {

            $this->error('亲！请登录', url('login/index'));
        } else {
            $member = new MemberModel();
            $uid = session('userid');
            $gzc = $member->find($uid);

            if (request()->isPost()) {
                $data = $this->request->post();
                $password = input('password');
                        $datam['password'] = substr(md5($password), 8, 16);
                        if ($member->save($datam, ['userid' => $uid])) {
                            return json(array('code' => 200, 'msg' => '修改成功'));
                        } else {
                            return json(array('code' => 0, 'msg' => '修改失败'));
                        }


            }
            $this->assign('gzc', $gzc);
            return view();
        }

    }
    public function headedit()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录', url('login/index'));
        } else {
            $member = new MemberModel();
            $uid = session('userid');
            if (request()->isPost()) {
                $data = input('post.');
               $_data['userhead'] = remove_xss($data['userhead']);
                if ($member->save($_data, ['userid' => $uid])) {
                    return json(array('code' => 200, 'msg' => '修改成功'));
                } else {
                    return json(array('code' => 0, 'msg' => '修改失败'));
                }
            }
            $gzc = $member->find($uid);
            $this->assign('gzc', $gzc);
            return view();
        }
    }
}