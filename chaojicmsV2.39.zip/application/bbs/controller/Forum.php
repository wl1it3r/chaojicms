<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\bbs\controller;
use think\Controller;
use think\Db;
use app\bbs\model\Forum as ForumModel;
class Forum extends Controller
{
    public function add()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('login/index'));
        } else {
            $forum = new ForumModel();
            if (request()->isPost()) {
                $input = input('post.');
                $data['time'] = time();
                $data['open'] = config('web.WEB_OPE');
                $data['view'] = 1;
                $data['tid']=$input['tid'];
                $data['uid'] = session('userid');
                $data['description'] = mb_substr(remove_xss($input['content']), 0, 200, 'utf-8');
                $data['title']   = strip_tags($input['title']);
                $data['keywords'] = remove_xss($input['keywords']);
                $data['content'] = remove_xss($input['content']);
                hook('phpadd');
                point(config('point.ADD_POINT'), session('userid'), '发帖：' . $input['title']);
                if ($forum->add($data)) {
                    return json(array('code' => 200, 'msg' => '添加成功'));
                } else {
                    return json(array('code' => 0, 'msg' => '添加失败'));
                }
            }
            $category = Db::name('category');
            $gzc = $category->where("tid = 0")->order('sort desc')->select();
            $gjm = $category->where("tid != 0")->order('sort desc')->select();
            $this->assign('gzc', $gzc);
            $this->assign('gjm', $gjm);
			$tags = config('web.WEB_TAG');
            $tagss = explode(',', $tags);
		    $this->assign('tagss', $tagss);
            return view();
        }
    }
    public function edit()
    {
        if (!session('userid') || !session('username')) {
            $this->error('亲！请登录',url('login/index'));
        } else {
            $id = input('id');
            $uid = session('userid');
            $forum = new ForumModel();
            $a = $forum->find($id);
            if (empty($id) || $a == null || $a['uid'] != $uid) {
                $this->error('亲！您迷路了');
            } else {
                if (request()->isPost()) {
                    $input = input('post.');
                    $data['tid']=$input['tid'];
                    $data['uid'] = session('userid');
                    $data['description'] = mb_substr(remove_xss($input['content']), 0, 200, 'utf-8');
                    $data['title']   = strip_tags($input['title']);
                    $data['keywords'] = remove_xss($input['keywords']);
                    $data['content'] = remove_xss($input['content']);
                    hook('phpedit');
                    $data['id'] = remove_xss($input['id']);
                    $data['times'] = time();
                    if ($forum->edit($data)) {
                        return json(array('code' => 200, 'msg' => '修改成功'));
                    } else {
                        return json(array('code' => 0, 'msg' => '修改失败'));
                    }
                }
                $category = Db::name('category');
                $gzc = $forum->find($id);
                $gzcs = $category->where("tid = 0")->order('sort desc')->select();
                $gjms = $category->where("tid != 0")->order('sort desc')->select();
                $this->assign('gzcs', $gzcs);
                $this->assign('gjms', $gjms);
                $this->assign(array('gzcs' => $gzcs, 'gzc' => $gzc));
				$tags = config('web.WEB_TAG');
                $tagss = explode(',', $tags);
		        $this->assign('tagss', $tagss);
                return view();
            }
        }
    }
}