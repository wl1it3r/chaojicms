<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
namespace app\bbs\controller;

 
use think\Controller;
use think\Db;
use Captcha\Captcha;
use think\Cache;
use think\Config;
use think\Session;
use think\Request;
use app\bbs\model\Member as MemberModel;

class Login extends Controller
{
    public function index()
    {
        $member = new MemberModel();
		if (request()->isPost()) {
            $data = input('post.');
			$status['status'] = 1;
			$myucms = $data['usermail'];
			$map['userid|usermail'] = $myucms;
            $user = $member->where($status)->where($map)->find();
 
            if ($user) {
                if ($user['password'] == substr(md5($data['password']), 8, 16)) {
					session('userhead', $user['userhead']);
                    session('username', $user['username']);
                    session('userid', $user['userid']);
					session('point', $user['point']);
                    $member->update(
                        [
                            'last_login_time' => time(),
                            'last_login_ip' => $this->request->ip(),
                            'userid' => $user['userid'],
                        ]
                    );
                    point(config('point.LOGIN_POINT'), session('userid'), 'login');
                    return json(array('code' => 200, 'msg' => '登录成功'));
                } else {
                    return json(array('code' => 0, 'msg' => '密码错误'));
                }
            } else {
                return json(array('code' => 0, 'msg' => '账号错误'));
            }
        }
        print s();return view();
    }
    public function reg()
    {
        $member = new MemberModel();
        $webreg = 1;
		if ($webreg != config('web.WEB_REG')) {
            $this->error('已关闭会员注册');
        }
        if (request()->isPost()) {
            $data = input('post.');
            $password = input('password');
            $passwords = input('passwords');
            $mail = $member->where('usermail', $data['usermail'])->find();
            session_start();   
            $imgId_req = $_REQUEST['yzm'];   
            if ($_SESSION['checkkey'] != $imgId_req){  
              $this->error('验证码错误');
            }  
 
            if (!$mail) {
                $user = $member->where('username', $data['username'])->find();
                if (!$user) {
                    if ($password != $passwords) {
                        return json(array('code' => 0, 'msg' => '密码错误'));
                    }
                    $data['regtime'] = time();
                    $data['grades'] = 0;
                    $data['status'] = config('web.WEB_REG');
                    $data['point'] = config('point.REG_POINT');
                    $data['userhead'] = '/public/img/touxiang.jpg';
                    $data['userip'] = $_SERVER['REMOTE_ADDR'];
                    $data['password'] = substr(md5($password), 8, 16);
                    if ($member->add($data)) {
                        return json(array('code' => 200, 'msg' => '注册成功'));
                    } else {
                        return json(array('code' => 0, 'msg' => '注册失败'));
                    }
                } else {
                    return json(array('code' => 0, 'msg' => '该昵称已存在'));
                }
            } else {
                return json(array('code' => 0, 'msg' => '该邮箱已存在'));
            }
        }
        print s();return view();
    }
 
    public function logout()
    {
        session("userid", NULL);
        session("username", NULL);
		session("usermail", NULL);
        session("kouling", NULL);
        return json(array('code' => 200, 'msg' => '退出成功'));
        return NULL;
    }
}