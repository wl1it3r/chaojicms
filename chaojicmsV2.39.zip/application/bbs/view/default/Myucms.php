<?php
return array(
'title'=>'默认模板',
'zuozhe'=>'梦雨',
'name'=>'default',
'pic'=>'/application/bbs/view/default/public/img/pic.jpg',	
'bb'=>'1.0',
'lianjie'=>'www.myucms.com',
);