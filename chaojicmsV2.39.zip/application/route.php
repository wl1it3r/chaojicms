<?php
/*
 *	www.myucms.com
 *  作者：梦雨
 *  @ QQ50361804
*/
//myucms路由控制
return [
    '__pattern__' => [ 'name' => '\w+', ],
/*插件*/
     'myu' => ['index/addons/myu',['ext'=>'html']],
/*社区*/
    '[home]' => [':id'   => ['bbs/user/home', ['id' => '\d+']],],
	'[thread]' => [ ':id'   => ['bbs/index/thread', ['id' => '\d+']], ],
	'[view]' => [':id'   => ['bbs/index/view', ['id' => '\d+']], ],
	'[bankuai]' => [':id'   => ['bbs/index/bankuai', ['id' => '\d+']], ],
	'[edit]' => [':id'   => ['bbs/forum/edit', ['id' => '\d+']],],
	'[edits]' => [':id'   => ['bbs/comment/edit', ['id' => '\d+']],],
	'choice' => ['bbs/index/choice',['ext'=>'html']],
	'search' => ['bbs/index/search',['ext'=>'html']],
	'add' => ['bbs/forum/add',['ext'=>'html']],
/*商城*/
    'grid' => ['shop/index/grid',['ext'=>'html']],
    'shop/tijiao' => ['shop/index/tijiao',['ext'=>'html']],
    '[grids]' => [':id'   => ['shop/index/grid', ['id' => '\d+']], ],
    '[goods]' => [':id'   => ['shop/index/goods', ['id' => '\d+']], ],
	'soso' => ['shop/index/search',['ext'=>'html']],
];
 