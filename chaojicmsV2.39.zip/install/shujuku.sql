-- MySQL dump 10.13  Distrib 5.5.62, for Linux (x86_64)
--
-- Host: localhost    Database: bbs_guojiz_com
-- ------------------------------------------------------
-- Server version	5.5.62-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `my_addons`
--

DROP TABLE IF EXISTS `my_addons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) DEFAULT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `pic` varchar(999) DEFAULT NULL COMMENT '图标封面',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='插件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_addons`
--

LOCK TABLES `my_addons` WRITE;
/*!40000 ALTER TABLE `my_addons` DISABLE KEYS */;
/*!40000 ALTER TABLE `my_addons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_banner`
--

DROP TABLE IF EXISTS `my_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pic` varchar(100) DEFAULT NULL COMMENT '图片',
  `time` varchar(32) DEFAULT NULL COMMENT '时间',
  `times` int(99) DEFAULT NULL,
  `title` varchar(9999) DEFAULT NULL COMMENT '标题',
  `links` varchar(100) DEFAULT NULL COMMENT '连接',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `lianjie` varchar(999) DEFAULT NULL COMMENT '链接',
  `fl` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_banner`
--

LOCK TABLES `my_banner` WRITE;
/*!40000 ALTER TABLE `my_banner` DISABLE KEYS */;
INSERT INTO `my_banner` VALUES (1,'','1568958679',0,'<a href=\"https://www.guojiz.com/thread/1.html\"target=\"_blank\" style=\"display: block;  position: relative; height: 60px;  line-height: 60px; margin-top: 10px; padding: 0 20px; text-align: center; font-size: 16px;font-weight: 300;color: #fff;background-color: #0063FF;\">\nGuojiz网址导航系统免费下载\n</a>','测试bbs首页广告',1,NULL,1),(3,'/uploads/20191012/3586abeb04c9d0dedc9cabd22dd3841d.png','1569122247',0,'<a href=\"http://www.myucms.com\" target=\"_blank\">										\n<img alt=\"/\" style=\"background: url(/uploads/20191012/3586abeb04c9d0dedc9cabd22dd3841d.png) no-repeat center;background-color: #ffffff;\"src=\"/application/shop/view/default/public/img/alpha.png\">										\n</a>','商城首页幻灯片',1,'/index.php',9),(4,'/uploads/20191012/7f069c77edd66cea27c90056e5610c41.png','1569123203',0,'<a href=\"http://www.myucms.com\" target=\"_blank\">										\n<img alt=\"/\" style=\"background: url(/uploads/20191012/7f069c77edd66cea27c90056e5610c41.png) no-repeat center;background-color: #ffffff;\"src=\"/application/shop/view/default/public/img/alpha.png\">										\n</a>','商城首页幻灯片 ',1,'/',9);
/*!40000 ALTER TABLE `my_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_category`
--

DROP TABLE IF EXISTS `my_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) DEFAULT NULL COMMENT '上级',
  `name` varchar(32) DEFAULT NULL COMMENT '名称',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `sidebar` tinyint(1) NOT NULL DEFAULT '1' COMMENT '侧栏',
  `sort` int(11) NOT NULL DEFAULT '1' COMMENT '排序',
  `pic` varchar(100) DEFAULT NULL COMMENT '图片',
  `time` varchar(32) DEFAULT NULL COMMENT '时间',
  `keywords` varchar(100) DEFAULT NULL COMMENT '关键词',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='社区分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_category`
--

LOCK TABLES `my_category` WRITE;
/*!40000 ALTER TABLE `my_category` DISABLE KEYS */;
INSERT INTO `my_category` VALUES (1,0,'测试顶级',1,1,0,1,'','1570875086','顶级板块','顶级板块'),(2,1,'测试板块',1,1,1,1,'','1570875098','测试板块','测试板块');
/*!40000 ALTER TABLE `my_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_comment`
--

DROP TABLE IF EXISTS `my_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) DEFAULT NULL COMMENT '上级评论',
  `uid` int(11) DEFAULT NULL COMMENT '所属会员',
  `fid` int(11) DEFAULT NULL COMMENT '所属帖子',
  `time` varchar(11) DEFAULT NULL COMMENT '时间',
  `praise` varchar(11) DEFAULT '0' COMMENT '赞',
  `reply` varchar(11) DEFAULT '0' COMMENT '回复',
  `content` text COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='评论表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_comment`
--

LOCK TABLES `my_comment` WRITE;
/*!40000 ALTER TABLE `my_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `my_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_file`
--

DROP TABLE IF EXISTS `my_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` varchar(255) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` varchar(255) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `score` int(10) NOT NULL DEFAULT '0' COMMENT '积分',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所有人',
  `md5` varchar(255) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` varchar(255) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  `download` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='附件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_file`
--

LOCK TABLES `my_file` WRITE;
/*!40000 ALTER TABLE `my_file` DISABLE KEYS */;
INSERT INTO `my_file` VALUES (1,'MYUCMS.png','7f069c77edd66cea27c90056e5610c41.png','/uploads/20191012/7f069c77edd66cea27c90056e5610c41.png','png','image/png',13470,0,1,'ce0b1d99fd7ffe97e7415ad44f1ff7d9','f220f077a1e3d3637b868c700d57960d52cdc7e5',1570875744,0),(2,'ico.png','d21c3ae29811970f11d9fda79a6bbf99.png','/uploads/20191012/d21c3ae29811970f11d9fda79a6bbf99.png','png','image/png',23009,0,1,'2ef6b2e93fc52c96f5bfb1f6fb7eea8a','975de5dd055fcca92a3277552efc4b97d154ed59',1570875795,0),(3,'qiniutu.png','3586abeb04c9d0dedc9cabd22dd3841d.png','/uploads/20191012/3586abeb04c9d0dedc9cabd22dd3841d.png','png','image/png',19019,0,1,'47dcf4028580a4527ab579edf79c50c8','9a94d6b413e6cb57f2cc982c5708600496711aeb',1570875817,0),(4,'MYUCMS (1).png','6bcfcacbf2130b9d101babd62e43a669.png','/uploads/20191012/6bcfcacbf2130b9d101babd62e43a669.png','png','image/png',25981,0,1,'96413680b20d853521e618c11c07af1f','ba3bffac7cfb8574c97a66a8add0e36cb31c16aa',1570875889,0);
/*!40000 ALTER TABLE `my_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_forum`
--

DROP TABLE IF EXISTS `my_forum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_forum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) DEFAULT NULL COMMENT '上级',
  `uid` int(11) DEFAULT NULL COMMENT '用户',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `open` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `choice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '精贴',
  `settop` tinyint(1) NOT NULL DEFAULT '0' COMMENT '顶置',
  `praise` varchar(11) NOT NULL DEFAULT '0' COMMENT '赞',
  `view` varchar(11) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `time` varchar(11) DEFAULT NULL COMMENT '时间',
  `times` varchar(999) NOT NULL COMMENT '修改时间',
  `reply` varchar(11) NOT NULL DEFAULT '0' COMMENT '回复',
  `keywords` varchar(100) DEFAULT NULL COMMENT '关键词',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `content` text COMMENT '内容',
  `lianjie` varchar(999) DEFAULT NULL COMMENT '附件链接',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_forum`
--

LOCK TABLES `my_forum` WRITE;
/*!40000 ALTER TABLE `my_forum` DISABLE KEYS */;
INSERT INTO `my_forum` VALUES (1,2,1,'这是我的第一个主题',1,0,0,'0','1','1570875195','','0','','&lt;p&gt;采用MyuCMS社区+商城内容管理系统搭建&lt;/p&gt;','&lt;p&gt;采用MyuCMS社区+商城内容管理系统搭建&lt;/p&gt;',NULL);
/*!40000 ALTER TABLE `my_forum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_hooks`
--

DROP TABLE IF EXISTS `my_hooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(2) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_hooks`
--

LOCK TABLES `my_hooks` WRITE;
/*!40000 ALTER TABLE `my_hooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `my_hooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_links`
--

DROP TABLE IF EXISTS `my_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL COMMENT '名称',
  `links` varchar(100) DEFAULT NULL COMMENT '连接',
  `fl` int(10) DEFAULT NULL COMMENT '分类',
  `time` varchar(32) DEFAULT NULL COMMENT '时间',
  `times` int(99) DEFAULT NULL,
  `pic` varchar(100) DEFAULT NULL COMMENT '图片',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `dj` int(11) DEFAULT '0',
  `px` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_links`
--

LOCK TABLES `my_links` WRITE;
/*!40000 ALTER TABLE `my_links` DISABLE KEYS */;
INSERT INTO `my_links` VALUES (1,'论坛','/',1,'1566789451',NULL,'',1,0,0),(2,'社区系统','/',2,'1569126078',NULL,'',1,1,0),(3,'商城','/shop',3,'1569126115',NULL,'',1,0,0),(4,'免元素','http://www.mys360.com',2,'1569134069',NULL,NULL,1,1,0);
/*!40000 ALTER TABLE `my_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_member`
--

DROP TABLE IF EXISTS `my_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_member` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `point` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `userip` varchar(32) DEFAULT NULL COMMENT 'IP',
  `username` varchar(32) DEFAULT NULL COMMENT '名称',
  `password` varchar(32) NOT NULL DEFAULT '49ba59abbe56e057' COMMENT '密码',
  `kouling` varchar(32) DEFAULT NULL COMMENT '口令',
  `usermail` varchar(32) DEFAULT NULL COMMENT '邮箱',
  `userhead` varchar(999) NOT NULL DEFAULT '/public/img/touxiang.jpg' COMMENT '头像',
  `regtime` varchar(32) DEFAULT NULL COMMENT '注册时间',
  `grades` tinyint(1) NOT NULL DEFAULT '0' COMMENT '等级',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '验证1表示正常2邮箱验证3手机认证5手机邮箱全部认证',
  `userhome` varchar(32) DEFAULT NULL COMMENT '家乡',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `last_login_time` varchar(20) DEFAULT '0' COMMENT '最后登陆时间',
  `last_login_ip` varchar(50) DEFAULT '' COMMENT '最后登录IP',
  `salt` varchar(20) DEFAULT NULL COMMENT 'salt',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `usermail` (`usermail`) USING BTREE,
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_member`
--

LOCK TABLES `my_member` WRITE;
/*!40000 ALTER TABLE `my_member` DISABLE KEYS */;
INSERT INTO `my_member` VALUES (1,999,NULL,'admin','7a57a5a743894a0e','123456','admin@admin.com','/uploads/20191012/6bcfcacbf2130b9d101babd62e43a669.png',NULL,1,0,1,'','341s','1570854262','43.247.208.25',NULL);
/*!40000 ALTER TABLE `my_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_point_note`
--

DROP TABLE IF EXISTS `my_point_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_point_note` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `controller` varchar(255) DEFAULT NULL,
  `uid` int(10) unsigned DEFAULT NULL,
  `pointid` int(10) unsigned DEFAULT NULL,
  `score` int(10) DEFAULT NULL,
  `add_time` int(10) unsigned DEFAULT NULL,
  `jiajian` varchar(99) NOT NULL COMMENT '增加减少',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_point_note`
--

LOCK TABLES `my_point_note` WRITE;
/*!40000 ALTER TABLE `my_point_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `my_point_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_set`
--

DROP TABLE IF EXISTS `my_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(999) DEFAULT '1' COMMENT '名称',
  `title` varchar(999) DEFAULT NULL COMMENT '标题',
  `time` int(99) DEFAULT NULL COMMENT '时间',
  `choice` tinyint(1) NOT NULL DEFAULT '1' COMMENT '选择',
  `set` varchar(999) DEFAULT NULL COMMENT '变量',
  `file` varchar(999) DEFAULT '1',
  `px` int(11) NOT NULL DEFAULT '1' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_set`
--

LOCK TABLES `my_set` WRITE;
/*!40000 ALTER TABLE `my_set` DISABLE KEYS */;
INSERT INTO `my_set` VALUES (2,'MyuCMS综合内容管理系统','网站描述',1570347522,3,'description','1',9),(3,'关键词,梦雨cms,myucms','关键词',1570875225,3,'keywords','1',9),(5,'00000','备案',1569686328,1,'icp','1',1),(6,'/public/img/logo.png','网站logo',1570347524,4,'logo','',13),(9,'MyuCMS社区+商城内容管理系统','标题',1570347523,1,'title','1',10),(12,'<script type=\"text/javascript\" src=\"https://s9.cnzz.com/z_stat.php?id=1277972876&web_id=1277972876\"></script>','统计代码',1568950634,3,'tongji','1',2),(13,'Copyright© 2019 梦雨cms版权所有','版权描述',1569686347,3,'banquan','1',2),(14,'0','全局控制',1568954959,0,'css','',1),(16,'MyuCMS社区+商城内容管理系统','商城标题',1570347521,1,'shoptitle','1',8),(17,'商城,shop,myucms,cms内容管理系统','商城关键词',1570347519,3,'shopkeywords','1',8),(18,'MyuCMS商城管理系统','商城描述',1570347517,3,'shopdescription','1',8),(27,'50361804','站长QQ',1569133468,1,'qq','1',1),(28,'/public/img/shop-logo.png','商城logo',1570346892,4,'shoplogo','',9),(29,'/favicon.ico','商城ico',1570347230,4,'shopico','',9),(30,'梦雨','作者',1569156493,1,'author','1',1);
/*!40000 ALTER TABLE `my_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_shopcate`
--

DROP TABLE IF EXISTS `my_shopcate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_shopcate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) DEFAULT NULL COMMENT '上级',
  `name` varchar(32) DEFAULT NULL COMMENT '名称',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `sidebar` tinyint(1) NOT NULL DEFAULT '1' COMMENT '侧栏',
  `sort` int(11) NOT NULL DEFAULT '1' COMMENT '排序',
  `pic` varchar(100) DEFAULT NULL COMMENT '图片',
  `time` varchar(32) DEFAULT NULL COMMENT '时间',
  `keywords` varchar(100) DEFAULT NULL COMMENT '关键词',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商城分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_shopcate`
--

LOCK TABLES `my_shopcate` WRITE;
/*!40000 ALTER TABLE `my_shopcate` DISABLE KEYS */;
/*!40000 ALTER TABLE `my_shopcate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_shopcomment`
--

DROP TABLE IF EXISTS `my_shopcomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_shopcomment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) DEFAULT NULL COMMENT '上级评论',
  `uid` int(11) DEFAULT NULL COMMENT '所属会员',
  `fid` int(11) DEFAULT NULL COMMENT '所属商品',
  `time` varchar(11) DEFAULT NULL COMMENT '时间',
  `praise` varchar(11) DEFAULT '0' COMMENT '赞',
  `reply` varchar(11) DEFAULT '0' COMMENT '回复',
  `content` text COMMENT '内容',
  `contents` text NOT NULL COMMENT '管理员回复',
  `pingfen` int(11) DEFAULT NULL COMMENT '评分',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商城评论表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_shopcomment`
--

LOCK TABLES `my_shopcomment` WRITE;
/*!40000 ALTER TABLE `my_shopcomment` DISABLE KEYS */;
/*!40000 ALTER TABLE `my_shopcomment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_shopdingdan`
--

DROP TABLE IF EXISTS `my_shopdingdan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_shopdingdan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dingdanid` varchar(16) DEFAULT NULL COMMENT '订单id',
  `uid` int(11) DEFAULT '1' COMMENT '用户',
  `tid` int(11) DEFAULT NULL COMMENT '上级',
  `title` varchar(999) DEFAULT NULL COMMENT '商品名称',
  `guige` varchar(999) DEFAULT NULL COMMENT '规格',
  `lianjie` varchar(999) DEFAULT NULL COMMENT '下载地址',
  `time` varchar(999) DEFAULT NULL COMMENT '时间',
  `times` varchar(999) DEFAULT NULL COMMENT '购买时间',
  `timef` varchar(999) DEFAULT NULL COMMENT '发货时间',
  `timess` varchar(99) DEFAULT NULL COMMENT '收货时间',
  `timep` varchar(999) DEFAULT NULL COMMENT '评价时间',
  `jifen` int(11) DEFAULT NULL COMMENT '积分',
  `open` int(1) DEFAULT NULL COMMENT '状态',
  `shuliang` int(11) NOT NULL DEFAULT '0' COMMENT '数量',
  `name` varchar(999) DEFAULT NULL COMMENT '名字',
  `dizhi` varchar(999) DEFAULT NULL COMMENT '地址',
  `lianxi` varchar(999) DEFAULT NULL COMMENT '联系',
  `wuliu` varchar(999) DEFAULT NULL COMMENT '物流信息',
  `xn` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_shopdingdan`
--

LOCK TABLES `my_shopdingdan` WRITE;
/*!40000 ALTER TABLE `my_shopdingdan` DISABLE KEYS */;
/*!40000 ALTER TABLE `my_shopdingdan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_shopdizhi`
--

DROP TABLE IF EXISTS `my_shopdizhi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_shopdizhi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '1' COMMENT '用户',
  `title` varchar(999) DEFAULT NULL COMMENT '备注',
  `lianxi` varchar(999) DEFAULT NULL COMMENT '联系方式',
  `time` varchar(999) DEFAULT NULL COMMENT '时间',
  `name` varchar(999) DEFAULT NULL COMMENT '名字',
  `dizhi` varchar(999) DEFAULT NULL COMMENT '地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_shopdizhi`
--

LOCK TABLES `my_shopdizhi` WRITE;
/*!40000 ALTER TABLE `my_shopdizhi` DISABLE KEYS */;
/*!40000 ALTER TABLE `my_shopdizhi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_shops`
--

DROP TABLE IF EXISTS `my_shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_shops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) DEFAULT NULL COMMENT '上级',
  `uid` int(11) DEFAULT NULL COMMENT '用户',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `open` tinyint(1) NOT NULL DEFAULT '1' COMMENT '显示',
  `choice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '精选',
  `settop` tinyint(1) NOT NULL DEFAULT '0' COMMENT '顶置',
  `praise` varchar(11) NOT NULL DEFAULT '0' COMMENT '赞',
  `view` varchar(11) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `sc` int(99) NOT NULL DEFAULT '0' COMMENT '收藏',
  `xiaoliang` int(99) NOT NULL DEFAULT '0' COMMENT '销量',
  `time` varchar(11) DEFAULT NULL COMMENT '时间',
  `reply` varchar(11) NOT NULL DEFAULT '0' COMMENT '评论',
  `keywords` varchar(100) DEFAULT NULL COMMENT '关键词',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  `content` text COMMENT '内容',
  `pic` varchar(2000) DEFAULT NULL COMMENT '封面',
  `xn` int(1) DEFAULT NULL COMMENT '是否虚拟商品',
  `jifen` int(11) DEFAULT NULL COMMENT '商品价格',
  `jifens` int(11) DEFAULT NULL COMMENT '原价',
  `lianjie` varchar(9990) DEFAULT NULL COMMENT '源文件',
  `kucun` int(99) NOT NULL DEFAULT '0' COMMENT '库存',
  `guige` varchar(6666) DEFAULT NULL COMMENT '规格',
  `pingjia` int(99) NOT NULL DEFAULT '0' COMMENT '评价',
  `销量` int(99) NOT NULL DEFAULT '0' COMMENT '销量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_shops`
--

LOCK TABLES `my_shops` WRITE;
/*!40000 ALTER TABLE `my_shops` DISABLE KEYS */;
/*!40000 ALTER TABLE `my_shops` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-12 18:29:29
